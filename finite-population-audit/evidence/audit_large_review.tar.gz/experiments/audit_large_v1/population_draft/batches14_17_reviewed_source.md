Lote 14 — elétrica
ID	Texto A	Texto B	Reparo principal
E209	O motor apresenta conexão estrela instalada onde o projeto exige triângulo para a tensão disponível.	As pontes do motor foram montadas em estrela, contrariando a ligação em triângulo especificada para a alimentação.	Corrigir a ligação
E210	A bobina do vibrador eletromagnético está eletricamente aberta.	O teste confirmou interrupção no enrolamento do vibrador eletromagnético.	Substituir ou recuperar a bobina
E211	O transformador apresenta conexão interna do terminal secundário com solda rompida.	A continuidade da saída secundária foi perdida na união soldada interna do transformador.	Recuperar a conexão
E212	O cabo de alimentação do aquecedor apresenta terminal carbonizado e contato resistivo elevado.	A medição localizou resistência excessiva no terminal queimado do cabo do aquecedor.	Refazer a terminação e avaliar danos
E213	O interruptor de transferência apresenta contato de potência eletricamente aberto na posição fechada.	O ensaio confirmou ausência de continuidade em um contato principal da chave de transferência acionada.	Recuperar ou substituir o conjunto
E214	O circuito de alimentação do painel apresenta condutor de neutro rompido.	O teste de continuidade identificou interrupção no cabo de neutro que alimenta o painel.	Substituir ou reparar o condutor
E215	A barra de proteção apresenta terminal frouxo, com continuidade inadequada confirmada por medição.	O ensaio confirmou ligação de proteção deficiente em um borne mal apertado da barra de terra.	Refazer a conexão
E216	O conjunto de contatos da chave seccionadora apresenta falha de isolamento entre polos.	O teste confirmou perda de isolação elétrica entre fases na seccionadora.	Substituir o conjunto comprometido
E217	A placa do inversor apresenta conector de alimentação auxiliar com solda trincada e contato intermitente.	A intermitência da alimentação auxiliar foi localizada na solda fissurada do conector da placa do inversor.	Recuperar a solda ou substituir a placa
E218	O resistor de equalização do banco de capacitores está eletricamente aberto.	O ensaio confirmou interrupção no resistor que equaliza a tensão entre capacitores do banco.	Substituir o resistor
E219	O sensor de tensão do conversor apresenta saída eletrônica em curto.	O teste identificou curto no estágio eletrônico de saída do transdutor de tensão do conversor.	Substituir o sensor
E220	O circuito de comando da ponte retificadora apresenta cabo de disparo interrompido.	A perda do sinal de disparo foi localizada em um condutor rompido do cabo de comando do retificador.	Reparar ou substituir o cabo
E221	O transmissor de vazão apresenta circuito de saída danificado, apesar da alimentação correta.	O ensaio confirmou defeito na eletrônica de saída do transmissor de vazão, com alimentação normal.	Reparar ou substituir o transmissor
E222	O sensor de posição apresenta alimentação ligada em polaridade invertida.	Os condutores positivo e negativo estão trocados nos terminais de alimentação do sensor de posição.	Corrigir a ligação
E223	O contato da botoeira de partida permanece aberto quando pressionado.	O acionamento correto da botoeira de partida não estabelece continuidade em seu contato.	Substituir o bloco de contato
E224	O cabo de comunicação apresenta um condutor do par diferencial interrompido.	O teste identificou circuito aberto em um fio do par diferencial da rede de comunicação.	Substituir ou reparar o cabo


Lote 14 — mecânica
ID	Texto A	Texto B	Reparo principal
M209	O rolamento apresenta elementos rolantes fraturados.	A inspeção confirmou ruptura de corpos rolantes no rolamento.	Substituir o rolamento
M210	O mancal apresenta tampa montada em posição incompatível com sua marcação de montagem.	A conferência confirmou montagem incorreta da tampa em relação ao corpo do mancal.	Corrigir a montagem e verificar o ajuste
M211	O eixo apresenta rosca da porca de retenção danificada.	A fixação axial não pode ser realizada corretamente porque a rosca do eixo está comprometida.	Recuperar ou substituir o eixo
M212	A transmissão apresenta corrente com lubrificação bloqueada por um canal obstruído no ponto de alimentação.	O óleo não alcança a corrente porque o canal de alimentação de lubrificante está bloqueado.	Desobstruir e verificar a lubrificação
M213	A bomba apresenta impulsor solto por afrouxamento da porca de retenção.	A porca de fixação do impulsor perdeu aperto e deixou o componente sem retenção adequada.	Restabelecer a fixação e avaliar danos
M214	A válvula apresenta sede solta por perda da fixação no corpo.	A inspeção confirmou que a sede se desloca em seu alojamento por falha de retenção.	Recuperar ou substituir o conjunto
M215	A tubulação apresenta suporte com parafuso de ancoragem solto.	A base do suporte da tubulação perdeu fixação porque a ancoragem afrouxou.	Restabelecer a fixação
M216	O redutor apresenta junta da tampa deslocada para fora do assentamento e vazamento.	A perda de óleo foi localizada na junta montada fora de posição entre tampa e carcaça do redutor.	Substituir a junta e corrigir a montagem
M217	O cilindro hidráulico apresenta tampa com trinca estrutural.	A inspeção confirmou fissura no corpo da tampa do cilindro hidráulico.	Substituir ou recuperar conforme avaliação
M218	O cilindro pneumático apresenta tubo interno com desgaste acima da tolerância.	A medição confirmou diâmetro interno excessivo por desgaste no tubo do cilindro pneumático.	Substituir o tubo ou conjunto
M219	A válvula hidráulica apresenta mola de centragem rompida.	O carretel perdeu sua força de centragem devido à ruptura da mola interna da válvula hidráulica.	Substituir a mola ou conjunto
M220	O tubo de lubrificação está dobrado e restringe a passagem de óleo.	Uma dobra na linha de lubrificação estrangula fisicamente o fluxo de óleo.	Substituir ou corrigir o trecho
M221	O transportador apresenta suporte do raspador fraturado.	A inspeção confirmou ruptura na estrutura que sustenta o raspador da correia.	Recuperar ou substituir o suporte
M222	O carro apresenta batente de parada com fixação solta.	O batente que limita o deslocamento do carro se movimenta porque sua fixação perdeu aperto.	Restabelecer a fixação
M223	A proteção articulada apresenta pino da dobradiça fraturado.	A inspeção confirmou ruptura do pino que articula a dobradiça da proteção.	Substituir o pino ou conjunto
M224	O mecanismo apresenta rolete seguidor com superfície de contato descascada.	A inspeção identificou desprendimento de material na pista externa do rolete seguidor.	Substituir o rolete


Lote 15 — elétrica
ID	Texto A	Texto B	Reparo principal
E225	O enrolamento do motor apresenta isolamento degradado por carbonização, com fuga confirmada para a carcaça.	O ensaio localizou fuga à estrutura do motor na região carbonizada da isolação do enrolamento.	Recuperar ou substituir o enrolamento
E226	O motor apresenta conexão dos condutores de fase invertida em relação ao sentido de rotação especificado.	O sentido incorreto de giro foi associado à troca de duas fases na ligação do motor.	Corrigir a sequência de fases
E227	O eletroímã de retenção apresenta curto interno entre espiras de sua bobina.	O ensaio confirmou curto entre espiras no enrolamento do eletroímã de retenção.	Substituir ou recuperar a bobina
E228	O terminal do transformador apresenta conexão aparafusada frouxa e aquecimento localizado.	O aquecimento no terminal do transformador foi associado à falta de aperto da ligação elétrica.	Refazer a conexão e avaliar danos
E229	O contato da chave de emergência por cabo não abre, apesar do acionamento correto do mecanismo.	O mecanismo da chave de emergência atua normalmente, mas seu contato permanece conduzindo.	Substituir o contato ou conjunto
E230	A tomada industrial apresenta curto interno entre fase e contato de proteção.	O ensaio confirmou ligação elétrica indevida entre um contato de fase e o contato de terra da tomada.	Substituir a tomada
E231	O circuito de iluminação do painel está interrompido no contato defeituoso do interruptor.	O teste localizou circuito aberto no interruptor que alimenta a iluminação interna do painel.	Substituir o interruptor
E232	A bobina do relé de interface está eletricamente aberta.	A medição confirmou interrupção no enrolamento do relé de interface.	Substituir o relé
E233	O circuito de potência apresenta conexão de barramento com parafuso rompido e perda de contato.	A ligação do barramento perdeu pressão de contato devido à ruptura do parafuso de fixação.	Recuperar a união e avaliar danos
E234	O capacitor de pré-carga do circuito auxiliar apresenta curto interno.	O ensaio confirmou curto-circuito no capacitor utilizado na pré-carga do circuito auxiliar.	Substituir o capacitor
E235	A placa de disparo apresenta alimentação ligada a um conector incorreto.	A conferência identificou o cabo de alimentação instalado em conector diferente do previsto na placa de disparo.	Corrigir a ligação e avaliar danos
E236	O enrolamento do reator de entrada apresenta fuga elétrica para o núcleo metálico.	O teste confirmou perda de isolamento entre a bobina do reator de entrada e seu núcleo.	Recuperar ou substituir o reator
E237	O sensor de vibração apresenta circuito eletrônico interno danificado, apesar da alimentação correta.	O ensaio confirmou falha eletrônica no sensor de vibração, com alimentação adequada.	Substituir o sensor
E238	O cabo do transmissor de temperatura apresenta ligação dos fios de sinal trocada em relação ao esquema.	A conferência identificou inversão dos condutores de sinal nos terminais do transmissor de temperatura.	Corrigir a ligação
E239	O contato de saída do controlador de temperatura permanece fechado por soldagem.	O comando de aquecimento não interrompe a continuidade porque o contato de saída do controlador está soldado.	Substituir o relé de saída ou controlador
E240	O circuito eletrônico do isolador de sinal analógico está danificado.	O teste confirmou defeito na eletrônica do módulo que isola o sinal analógico.	Reparar ou substituir o módulo


Lote 15 — mecânica
ID	Texto A	Texto B	Reparo principal
M225	O rolamento apresenta pista com desgaste por passagem de partículas abrasivas.	A inspeção confirmou desgaste abrasivo na superfície da pista do rolamento.	Substituir e corrigir a contaminação
M226	O acoplamento apresenta parafusos montados sem o travamento especificado e com afrouxamento confirmado.	A ausência do sistema de travamento previsto permitiu que os parafusos do acoplamento perdessem aperto.	Corrigir a montagem e verificar a união
M227	A roda dentada apresenta cubo com trinca estrutural.	A inspeção confirmou fissura no cubo da roda dentada da transmissão.	Substituir a roda
M228	O redutor apresenta eixo montado com espaçador de comprimento incorreto.	A conferência dimensional identificou espaçador incompatível com a montagem especificada do eixo do redutor.	Instalar o espaçador correto e verificar ajustes
M229	O corpo da bomba apresenta alojamento do selo com desgaste além da tolerância.	A medição confirmou perda do ajuste especificado no alojamento do selo da bomba por desgaste.	Recuperar ou substituir conforme avaliação
M230	A válvula apresenta gaxeta montada com anéis de dimensão incorreta.	A vedação da haste foi montada com anéis de gaxeta incompatíveis com as dimensões especificadas.	Instalar as gaxetas corretas
M231	A tubulação apresenta abraçadeira apertada além da especificação, deformando o tubo.	O aperto excessivo do suporte provocou deformação confirmada na parede da tubulação.	Corrigir o apoio e avaliar o tubo
M232	O flange apresenta corrosão excessiva na face de assentamento da junta.	A inspeção confirmou ataque corrosivo além do limite na superfície de vedação do flange.	Recuperar ou substituir conforme avaliação
M233	O pistão hidráulico apresenta vedação instalada com orientação contrária à especificada.	A conferência de montagem confirmou inversão do sentido previsto para a vedação do pistão hidráulico.	Corrigir a montagem e substituir a vedação se necessário
M234	A mangueira pneumática apresenta abrasão externa com exposição da camada estrutural.	O atrito removeu a cobertura da mangueira de ar até expor sua camada de sustentação.	Substituir a mangueira e corrigir o atrito
M235	O filtro de ar apresenta copo montado sem o anel de vedação previsto.	A união do copo ao filtro pneumático está sem seu elemento vedante especificado.	Instalar a vedação correta
M236	O bloco distribuidor hidráulico apresenta trinca com vazamento externo de óleo.	A perda de óleo foi localizada em uma fissura no corpo do bloco distribuidor.	Substituir ou recuperar conforme avaliação
M237	O transportador apresenta eixo do tambor com assento de rolamento desgastado.	A medição confirmou desgaste acima da tolerância no assento do rolamento do eixo do tambor.	Recuperar ou substituir o eixo
M238	A roda do carro apresenta flange desgastado abaixo da espessura mínima.	A verificação dimensional confirmou redução excessiva da espessura do flange da roda do carro.	Substituir a roda
M239	A proteção apresenta visor com fixação quebrada e risco de desprendimento.	O visor da proteção perdeu retenção porque seus elementos de fixação estão rompidos.	Recuperar a fixação ou substituir o conjunto
M240	A articulação apresenta pino sem o ajuste de interferência previsto no suporte.	A medição confirmou fixação insuficiente do pino no suporte por falta da interferência especificada.	Recuperar o ajuste ou substituir componentes


Lote 16 — elétrica
ID	Texto A	Texto B	Reparo principal
E241	O enrolamento do solenóide de travamento apresenta curto entre espiras.	O ensaio confirmou curto interno entre espiras da bobina do solenóide de travamento.	Substituir a bobina ou conjunto
E242	O cabo de alimentação do motor apresenta condutor com filamentos rompidos e resistência excessiva.	A medição confirmou resistência elevada no cabo do motor associada à ruptura parcial dos filamentos condutores.	Substituir o trecho
E243	A resistência de aquecimento apresenta ligação elétrica interrompida na união entre dois elementos.	O circuito do aquecedor está aberto na conexão que interliga dois elementos resistivos.	Recuperar a conexão ou substituir o conjunto
E244	O resistor de campo apresenta cursor sem contato elétrico adequado com a pista.	O ensaio confirmou perda de continuidade no contato do cursor do resistor de ajuste de campo.	Recuperar ou substituir o conjunto
E245	O contato de indicação de fusível atuado está eletricamente defeituoso, apesar do acionamento mecânico correto.	O mecanismo sinalizador do fusível atua normalmente, mas seu contato elétrico não comuta.	Substituir o contato ou conjunto
E246	O cabo da alimentação auxiliar do painel apresenta curto entre os condutores positivo e negativo.	O ensaio localizou curto-circuito entre os dois fios da alimentação contínua auxiliar do painel.	Substituir ou reparar o cabo
E247	A chave comutadora apresenta terminal de saída desconectado internamente.	A continuidade da saída da chave foi perdida por ruptura de sua ligação interna ao terminal.	Substituir ou recuperar a chave
E248	O relé de falta de corrente apresenta entrada eletrônica de medição danificada.	O ensaio confirmou defeito no circuito de aquisição de corrente do relé de supervisão.	Reparar ou substituir o relé
E249	O circuito de alimentação do driver apresenta resistor fusível eletricamente aberto.	O teste confirmou interrupção no resistor fusível da alimentação do driver de potência.	Corrigir a causa e substituir o componente
E250	A placa do conversor apresenta oxidação condutiva entre terminais, com fuga elétrica confirmada.	Os depósitos de corrosão na placa formaram um caminho de corrente indevida entre seus terminais.	Recuperar ou substituir a placa
E251	O indutor do filtro apresenta terminal de enrolamento rompido.	A continuidade da bobina do filtro foi perdida por ruptura de seu terminal externo.	Recuperar ou substituir o indutor
E252	O circuito de detecção de sobretemperatura do acionamento está eletronicamente danificado.	O teste confirmou falha na eletrônica que recebe e processa a indicação de sobretemperatura do acionamento.	Reparar ou substituir a placa
E253	O sensor de deslocamento apresenta enrolamento de excitação eletricamente aberto.	A medição confirmou interrupção na bobina de excitação do transdutor de deslocamento.	Substituir ou recuperar o transdutor
E254	O circuito do encoder apresenta alimentação ligada a um terminal de sinal por erro de montagem.	A conferência identificou o fio de alimentação do encoder conectado indevidamente a um borne de sinal.	Corrigir a ligação e avaliar danos
E255	O módulo de saída digital apresenta contato de relé soldado em um canal.	Um canal de saída do módulo permanece fechado porque os contatos de seu relé estão soldados.	Substituir o relé ou módulo
E256	O circuito eletrônico da fonte do transmissor está danificado e não fornece alimentação à eletrônica interna.	A ausência de tensão interna do transmissor foi localizada em defeito de sua fonte eletrônica.	Reparar ou substituir o transmissor


Lote 16 — mecânica
ID	Texto A	Texto B	Reparo principal
M241	O rolamento apresenta anel interno fraturado.	A inspeção confirmou ruptura do anel interno do rolamento.	Substituir o rolamento
M242	O eixo apresenta estriado com dente fraturado.	A inspeção identificou ruptura de um dente no trecho estriado do eixo.	Substituir ou recuperar conforme avaliação
M243	A corrente apresenta rolete de elo mecanicamente travado.	A inspeção confirmou que um dos roletes da corrente não gira por travamento mecânico.	Substituir os componentes conforme especificação
M244	A polia apresenta fixação axial sem o anel de retenção especificado.	A montagem da polia está sem o anel que limita seu deslocamento axial no eixo.	Instalar o elemento e verificar a montagem
M245	A bomba apresenta eixo com rosca de retenção do impulsor danificada.	A porca do impulsor não pode ser fixada conforme especificação porque a rosca do eixo está comprometida.	Recuperar ou substituir o eixo
M246	A válvula apresenta obturador com revestimento elastomérico desprendido.	A inspeção confirmou perda de adesão do revestimento de borracha do obturador da válvula.	Substituir ou recuperar o conjunto
M247	A tubulação apresenta união roscada com engajamento insuficiente por montagem incorreta.	A conexão foi montada com poucos filetes engajados, abaixo do mínimo especificado.	Corrigir a montagem e verificar os componentes
M248	O mancal da bomba apresenta tampa com parafusos frouxos.	A fixação da tampa do mancal da bomba perdeu aperto nos parafusos.	Restabelecer a fixação e avaliar danos
M249	O cilindro hidráulico apresenta anel de retenção da tampa fora do alojamento.	A inspeção confirmou que o anel de travamento da tampa do cilindro hidráulico não está assentado em sua ranhura.	Corrigir a montagem e avaliar componentes
M250	A válvula pneumática apresenta corpo trincado com vazamento de ar.	A perda de ar foi localizada em uma fissura na carcaça da válvula pneumática.	Substituir a válvula ou corpo
M251	O regulador hidráulico apresenta parafuso de ajuste com rosca danificada.	A regulagem do conjunto hidráulico está comprometida pelo dano na rosca de seu parafuso de ajuste.	Substituir ou recuperar os componentes
M252	O tubo de graxa apresenta terminal roscado fraturado.	A inspeção confirmou ruptura do terminal que conecta a linha de graxa ao conjunto.	Substituir o terminal ou trecho
M253	O transportador apresenta suporte de mancal com furo de fixação ovalizado.	A medição confirmou desgaste excessivo no furo de ancoragem do suporte do mancal do transportador.	Recuperar ou substituir o suporte
M254	O carro apresenta para-choque com elemento amortecedor ausente.	O conjunto de fim de curso do carro está sem a peça prevista para absorver impactos.	Instalar o elemento especificado
M255	A proteção apresenta dobradiça montada fora de alinhamento, causando esforço de abertura excessivo.	O desalinhamento das dobradiças provoca resistência mecânica indevida ao movimento da proteção.	Corrigir a montagem
M256	O mecanismo apresenta came com superfície de contato desgastada além da tolerância.	A medição confirmou desgaste excessivo no perfil de trabalho do came.	Substituir ou recuperar conforme especificação


Lote 17 — elétrica
ID	Texto A	Texto B	Reparo principal
E257	O enrolamento da bobina de sustentação do eletroímã apresenta fuga para o núcleo.	O teste confirmou perda de isolamento entre a bobina de sustentação do eletroímã e seu núcleo metálico.	Substituir ou recuperar a bobina
E258	A conexão do motor apresenta terminal instalado sem prender todos os filamentos do condutor, causando aquecimento.	O aquecimento foi associado à terminação defeituosa que deixa parte dos filamentos fora da fixação do borne do motor.	Refazer a terminação
E259	O transformador apresenta conexão do aterramento do núcleo eletricamente interrompida.	O teste confirmou perda de continuidade na ligação de aterramento do núcleo do transformador.	Recuperar a conexão
E260	O cabo do banco de baterias está conectado com polaridade invertida no equipamento.	A conferência identificou troca dos cabos positivo e negativo entre o banco de baterias e o equipamento.	Corrigir a ligação e avaliar danos
E261	O contato da chave de transferência permanece fechado por soldagem.	O ensaio confirmou contatos soldados na chave de transferência, impedindo sua abertura elétrica.	Substituir o conjunto comprometido
E262	O circuito eletrônico do monitor de isolamento apresenta defeito confirmado por resistência de teste.	O ensaio com resistência de referência confirmou falha interna no monitor de isolamento.	Substituir ou reparar o monitor
E263	A ligação de proteção entre dois painéis apresenta resistência elevada em uma conexão oxidada.	O ensaio confirmou continuidade de proteção inadequada na união oxidada entre os dois quadros.	Recuperar a conexão
E264	O conector de alimentação apresenta pino com isolamento rompido e contato indevido com a carcaça metálica.	A falha dielétrica do conector permite passagem de corrente de um terminal energizado para seu invólucro.	Substituir o conector
E265	O circuito de alimentação do ventilador do inversor está interrompido por cabo rompido.	O ventilador do inversor não recebe energia porque um condutor de sua alimentação está partido.	Reparar ou substituir o cabo
E266	O diodo de proteção em paralelo com a bobina do contator está em curto.	O ensaio localizou curto interno no diodo de supressão ligado aos terminais da bobina do contator.	Substituir o diodo
E267	O resistor de medição de corrente do conversor apresenta elemento resistivo interrompido.	O ensaio confirmou circuito aberto no shunt usado para medir a corrente do conversor.	Substituir o componente
E268	O circuito de comando do retificador apresenta sinal invertido por ligação incorreta dos condutores de referência.	A conferência confirmou troca dos fios da referência de comando nos terminais do retificador.	Corrigir a ligação
E269	O contato elétrico da chave de temperatura permanece aberto, apesar do acionamento térmico normal.	O mecanismo responde à temperatura corretamente, mas o contato da chave não estabelece continuidade.	Substituir a chave ou contato
E270	O cabo do sensor de proximidade apresenta curto entre a saída e o positivo da alimentação.	O ensaio identificou ligação indevida entre o fio de sinal e o fio positivo no cabo do sensor de proximidade.	Reparar ou substituir o cabo
E271	O módulo de entrada de resistência apresenta circuito eletrônico de medição danificado.	O teste com resistor de referência confirmou falha na eletrônica de aquisição do módulo de resistência.	Reparar ou substituir o módulo
E272	O circuito do sinalizador sonoro apresenta bobina eletricamente aberta.	O teste de continuidade confirmou interrupção no enrolamento do sinalizador sonoro.	Substituir a bobina ou sinalizador


Lote 17 — mecânica
ID	Texto A	Texto B	Reparo principal
M257	O rolamento apresenta vedação lateral rompida, permitindo entrada de contaminantes.	A proteção vedante do rolamento está rasgada e deixou de impedir a entrada de resíduos.	Substituir conforme especificação
M258	O acoplamento apresenta cubo montado em posição axial diferente da especificada.	A conferência dimensional identificou posicionamento incorreto do cubo do acoplamento ao longo do eixo.	Corrigir a montagem
M259	O redutor apresenta engrenagem montada com chaveta de dimensão insuficiente.	A ligação da engrenagem ao eixo usa uma chaveta menor que a especificada para o conjunto.	Instalar a chaveta correta e avaliar danos
M260	A correia apresenta desgaste lateral causado por contato com proteção deformada.	A carenagem empenada roça na borda da correia e provoca desgaste confirmado.	Recuperar a proteção e substituir a correia se necessário
M261	A bomba apresenta suporte do selo mecânico deformado.	A inspeção confirmou alteração geométrica no alojamento de suporte do selo mecânico da bomba.	Recuperar ou substituir conforme avaliação
M262	A válvula apresenta porca de acionamento com rosca interna desgastada.	A transmissão de movimento à haste está comprometida pelo desgaste da rosca da porca de acionamento.	Substituir os componentes desgastados
M263	A tubulação apresenta redução concêntrica instalada onde o projeto exige excêntrica na sucção da bomba.	A conferência de montagem identificou redutor concêntrico no lugar da peça excêntrica prevista para a sucção.	Corrigir a montagem conforme projeto
M264	A junta de expansão apresenta limitador de curso montado com folga fora da especificação.	O ajuste dos limitadores permite deslocamento diferente do previsto na junta de expansão.	Corrigir a regulagem
M265	O cilindro hidráulico apresenta vedação da haste endurecida e com vazamento externo.	A perda de flexibilidade do vedante da haste foi associada ao vazamento externo do cilindro hidráulico.	Substituir a vedação e investigar a degradação
M266	O cilindro pneumático apresenta haste desconectada do pistão por falha da união roscada.	A ligação roscada entre pistão e haste se soltou, interrompendo a transmissão de movimento no cilindro pneumático.	Recuperar a união ou substituir componentes
M267	O reservatório hidráulico apresenta indicador mecânico de nível com boia perfurada.	O indicador de nível falhou porque sua boia perdeu estanqueidade por perfuração.	Substituir a boia ou conjunto
M268	A mangueira de graxa apresenta cobertura cortada com dano confirmado na camada estrutural.	A inspeção identificou corte que atravessa a cobertura e compromete o reforço da mangueira de lubrificação.	Substituir a mangueira
M269	O transportador apresenta saia de vedação lateral desgastada e sem contato com a correia.	O desgaste da borracha lateral deixou uma abertura entre a saia de contenção e a correia do transportador.	Substituir e ajustar a saia
M270	O carro apresenta roda montada com espaçador ausente, causando folga axial excessiva.	A montagem da roda está sem o espaçador previsto e permite deslocamento axial acima do limite.	Instalar a peça e verificar o ajuste
M271	A proteção apresenta fechadura mecânica com lingueta fraturada.	O travamento da proteção falhou por ruptura da lingueta da fechadura mecânica.	Substituir a fechadura ou conjunto
M272	O mecanismo apresenta mola de compressão com deformação permanente acima do limite permitido.	A medição confirmou perda permanente de comprimento da mola de compressão além da tolerância.	Substituir a mola

