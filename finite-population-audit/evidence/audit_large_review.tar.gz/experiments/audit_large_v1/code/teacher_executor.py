import argparse
import hashlib
import importlib.util
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path("experiments/audit_large_v1")
SETTINGS_HASH = "7eee96fd3fba6a6d740ce24a1be85775508ef938a15a8df6d889b425d819c738"
POP_HASH = "719f66a571b90bd2cb7429d859b391ca0b66bc177e5c56c63d85f8aab8dd52f3"
TABLE_HASH = "d8e79ce6f2bc3586cb08f7e76e18f10c033f484ec863cabbd2047d285d2ff3cf"
METHODS_HASH = "8f0dba8a0d5ab1dc85bd85cc630f947fcbf32c229f99053c872ad6fa32cbba06"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()

def read_checked(path, expected):
    raw = path.read_bytes()
    if sha(raw) != expected:
        raise RuntimeError(f"Hash diferente: {path}")
    return json.loads(raw)

def save_fixed(path, value):
    raw = encoded(value)
    if path.exists():
        if path.read_bytes() != raw:
            raise RuntimeError(f"Arquivo anterior diferente: {path}")
    else:
        with path.open("xb") as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
    return sha(raw)

def utc():
    return datetime.now(timezone.utc).isoformat()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=[
        "prepare", "collect_sample", "analyze_sample",
        "collect_complement", "analyze_full",
    ])
    args = parser.parse_args()

    settings = read_checked(ROOT / "execution_settings.json", SETTINGS_HASH)
    population = read_checked(ROOT / "population.json", POP_HASH)
    table = read_checked(ROOT / "student_table.json", TABLE_HASH)
    methods = read_checked(ROOT / "methods_manifest.json", METHODS_HASH)

    for name, expected in methods["code_sha256"].items():
        read_bytes = (ROOT / "code" / name).read_bytes()
        if sha(read_bytes) != expected:
            raise RuntimeError(f"Método alterado: {name}")

    code = Path(__file__).read_bytes()
    code_hash = sha(code)
    manifest = {
        "settings_sha256": SETTINGS_HASH,
        "population_sha256": POP_HASH,
        "student_table_sha256": TABLE_HASH,
        "methods_manifest_sha256": METHODS_HASH,
        "executor_sha256": code_hash,
        "sample_schema": {
            "selected_ids": "768 unique IDs",
            "ordered_ids": "Full permutation of 2048 IDs",
            "commitment_sha256": "Hash of pre_beacon_commitment.json",
        },
    }

    if args.stage == "prepare":
        target = ROOT / "code/teacher_executor.py"
        if target.exists():
            if target.read_bytes() != code:
                raise RuntimeError("Executor anterior diferente.")
        else:
            with target.open("xb") as handle:
                handle.write(code)
        manifest_hash = save_fixed(
            ROOT / "teacher_executor_manifest.json", manifest
        )
        print("EXECUTOR DO TEACHER E CERTIFICADO FIXADO")
        print("SHA256 do executor:", code_hash)
        print("SHA256 do manifesto:", manifest_hash)
        print("Nenhuma consulta à API; nenhum sorteio realizado.")
        return

    if (
        (ROOT / "code/teacher_executor.py").read_bytes() != code
        or json.loads(
            (ROOT / "teacher_executor_manifest.json").read_text()
        ) != manifest
    ):
        raise RuntimeError("Executor diferente do preparado.")

    commitment_raw = (ROOT / "pre_beacon_commitment.json").read_bytes()
    commitment_hash = sha(commitment_raw)
    commitment = json.loads(commitment_raw)

    expected_artifacts = {
        "population.json": POP_HASH,
        "execution_settings.json": SETTINGS_HASH,
        "student_table.json": TABLE_HASH,
        "methods_manifest.json": METHODS_HASH,
        "code/teacher_executor.py": code_hash,
    }
    for name, expected in expected_artifacts.items():
        if commitment["artifact_sha256"].get(name) != expected:
            raise RuntimeError(f"Compromisso incompatível: {name}")

    sample_raw = (ROOT / "sample.json").read_bytes()
    sample_hash = sha(sample_raw)
    sample = json.loads(sample_raw)
    rows = {r["id"]: r for r in population["rows"]}
    student = {r["id"]: r["response"] for r in table["rows"]}
    ordered = sample["ordered_ids"]
    selected = sample["selected_ids"]

    if (
        sample["commitment_sha256"] != commitment_hash
        or len(ordered) != 2048
        or len(set(ordered)) != 2048
        or set(ordered) != set(rows)
        or selected != ordered[:768]
        or len(selected) != 768
    ):
        raise RuntimeError("Sorteio incompatível.")

    selected_set = set(selected)
    complement = [i for i in ordered if i not in selected_set]
    mapping = settings["teacher_normalization"]["mapping"]

    responses = ROOT / "teacher_responses"
    attempts = ROOT / "teacher_attempts"

    def request_for(identifier):
        row = rows[identifier]
        config = settings["teacher_request"]
        return {
            "model": config["model"],
            "temperature": config["temperature"],
            "max_completion_tokens": config["max_completion_tokens"],
            "messages": [{
                "role": "user",
                "content": settings["prompt_prefix"] + row["text"],
            }],
        }

    def validate(record, identifier):
        if (
            record["id"] != identifier
            or record["commitment_sha256"] != commitment_hash
            or record["sample_sha256"] != sample_hash
            or record["executor_sha256"] != code_hash
            or record["request"] != request_for(identifier)
        ):
            raise RuntimeError(f"Registro incompatível: {identifier}")

        response = record["response"]
        choice = response["choices"][0]
        text = choice["message"].get("content")
        label = mapping.get(text.strip()) if isinstance(text, str) else None
        if (
            response.get("model") != settings["teacher_request"]["model"]
            or choice.get("finish_reason") != "stop"
            or label is None
        ):
            raise RuntimeError(
                f"Resposta preservada requer inspeção: {identifier}; "
                f"texto={text!r}; encerramento={choice.get('finish_reason')!r}"
            )
        return label

    def analyze(ids):
        results = []
        tokens = 0
        for identifier in ids:
            record = json.loads(
                (responses / f"{identifier}.json").read_text()
            )
            label = validate(record, identifier)
            tokens += (record["response"].get("usage") or {}).get(
                "total_tokens", 0
            )
            results.append({
                "id": identifier,
                "family_id": rows[identifier]["family_id"],
                "student": student[identifier],
                "teacher": label,
                "manual": rows[identifier]["manual_label"],
                "disagreement": student[identifier] != label,
            })

        spec = importlib.util.spec_from_file_location(
            "large_audit_analysis", ROOT / "code/analysis.py"
        )
        analysis = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(analysis)
        k = sum(r["disagreement"] for r in results)
        return {
            "settings_sha256": SETTINGS_HASH,
            "population_sha256": POP_HASH,
            "student_table_sha256": TABLE_HASH,
            "commitment_sha256": commitment_hash,
            "sample_sha256": sample_hash,
            "executor_sha256": code_hash,
            "certificate": analysis.certificate(k, len(ids)),
            "teacher_manual_disagreements": sum(
                r["teacher"] != r["manual"] for r in results
            ),
            "teacher_total_tokens": tokens,
            "scope": "Committed finite population under stated assumptions",
            "results": results,
        }

    # O complemento só pode ser iniciado após o certificado primário.
    if args.stage in ("collect_complement", "analyze_full"):
        primary = json.loads((ROOT / "primary_certificate.json").read_text())
        if primary != analyze(selected):
            raise RuntimeError("Certificado primário inconsistente.")

    if args.stage in ("collect_sample", "collect_complement"):
        from groq import Groq

        responses.mkdir(exist_ok=True)
        attempts.mkdir(exist_ok=True)
        config = settings["teacher_request"]
        client = Groq(
            timeout=config["timeout_seconds"],
            max_retries=config["sdk_max_retries"],
        )
        ids = selected if args.stage == "collect_sample" else complement

        for position, identifier in enumerate(ids, start=1):
            path = responses / f"{identifier}.json"
            attempt_path = attempts / f"{identifier}.json"

            if path.exists():
                validate(json.loads(path.read_text()), identifier)
                continue
            if attempt_path.exists():
                raise RuntimeError(
                    f"Tentativa sem resposta concluída: {identifier}. "
                    "Não será reenviada automaticamente; inspecionar."
                )

            request = request_for(identifier)
            started_utc = utc()
            save_fixed(attempt_path, {
                "id": identifier,
                "started_utc": started_utc,
                "commitment_sha256": commitment_hash,
                "sample_sha256": sample_hash,
                "request": request,
            })
            print(
                f"Teacher {position}/{len(ids)}: {identifier}",
                flush=True,
            )
            started = time.perf_counter()
            try:
                response = client.chat.completions.create(**request)
            except Exception as error:
                save_fixed(attempts / f"{identifier}.error.json", {
                    "id": identifier,
                    "ended_utc": utc(),
                    "error_type": type(error).__name__,
                    "http_status": getattr(error, "status_code", None),
                    "automatic_retry": False,
                })
                raise SystemExit(
                    f"Parada: {type(error).__name__}; "
                    f"tentativa de {identifier} preservada."
                )

            record = {
                "id": identifier,
                "commitment_sha256": commitment_hash,
                "sample_sha256": sample_hash,
                "executor_sha256": code_hash,
                "started_utc": started_utc,
                "ended_utc": utc(),
                "wall_seconds": time.perf_counter() - started,
                "request": request,
                "response": response.model_dump(mode="json"),
            }
            save_fixed(path, record)
            validate(record, identifier)
            time.sleep(config["pause_after_success_seconds"])

        print("COLETA CONCLUÍDA:", args.stage, flush=True)
        return

    ids = selected if args.stage == "analyze_sample" else ordered
    report = analyze(ids)
    target = ROOT / (
        "primary_certificate.json"
        if args.stage == "analyze_sample"
        else "full_reference.json"
    )
    report_hash = save_fixed(target, report)
    print(json.dumps({
        k: v for k, v in report.items() if k != "results"
    }, ensure_ascii=False, indent=2), flush=True)
    print("SHA256:", report_hash, flush=True)
    print("Resultado:", target, flush=True)

if __name__ == "__main__":
    main()
