ID	Texto A	Texto B	Reparo principal
E337	A bobina da válvula de descarga apresenta fuga elétrica para o corpo metálico.	O ensaio confirmou perda de isolamento entre o enrolamento da válvula de descarga e sua carcaça.	Substituir a bobina ou conjunto
E338	O motor apresenta ponte de ligação entre terminais com seção inferior à especificada e aquecimento confirmado.	A interligação dos terminais do motor aquece porque foi montada com seção condutiva insuficiente.	Instalar a ponte especificada e avaliar danos
E339	O transformador apresenta terminal de neutro com ligação interna interrompida.	O teste confirmou circuito aberto na conexão interna ao terminal de neutro do transformador.	Recuperar a ligação
E340	O aquecedor de imersão apresenta fuga elétrica para sua bainha metálica.	O ensaio confirmou perda de isolamento entre o elemento resistivo e a bainha do aquecedor de imersão.	Substituir o aquecedor
E341	A chave de comando apresenta contato móvel solto, causando continuidade intermitente.	O teste identificou interrupções elétricas provocadas pela folga do contato móvel da chave de comando.	Substituir o contato ou conjunto
E342	O barramento apresenta suporte isolante com fixação solta, permitindo aproximação indevida entre partes energizadas e estrutura.	A perda de aperto do suporte isolante compromete as distâncias de montagem do barramento.	Corrigir a fixação e conferir as distâncias
E343	O fusível de medição foi substituído por modelo incompatível com a especificação do circuito.	A conferência identificou fusível diferente do previsto na proteção da entrada de medição.	Instalar o componente especificado
E344	A ligação de proteção do painel está conectada ao borne errado e sem continuidade para a carcaça.	O ensaio confirmou que o condutor de proteção foi terminado em ponto que não estabelece ligação à estrutura do painel.	Corrigir a ligação
E345	O circuito eletrônico de alimentação dos drivers apresenta tensão fora da especificação por defeito interno.	O ensaio confirmou falha de regulação na fonte que alimenta os drivers do conversor.	Reparar ou substituir a fonte
E346	O resistor de descarga de um capacitor do filtro está desconectado em um terminal.	A ligação do resistor que descarrega o capacitor do filtro está aberta por desconexão de seu terminal.	Restabelecer a conexão
E347	O terminal de entrada do retificador apresenta conexão montada com arruela isolante indevida entre superfícies condutoras.	A continuidade da entrada do retificador foi comprometida por uma peça isolante instalada na união elétrica.	Corrigir a montagem
E348	O circuito de disparo apresenta receptor óptico eletronicamente danificado.	O teste confirmou falha no receptor que converte o comando óptico em sinal elétrico de disparo.	Substituir o receptor ou placa
E349	O sensor de nível capacitivo apresenta eletrônica interna em curto na alimentação.	O diagnóstico confirmou curto interno no circuito de alimentação do sensor capacitivo de nível.	Substituir o sensor
E350	O cabo do transmissor apresenta terminal de sinal desconectado dentro da caixa de junção.	A perda do sinal foi localizada em um fio solto no borne da caixa de junção do transmissor.	Restabelecer a conexão
E351	O contato da chave seletora de sentido está eletricamente aberto na posição de avanço.	O ensaio confirmou ausência de continuidade no contato correspondente ao avanço da chave de sentido.	Substituir o bloco de contato
E352	O módulo de medição de tensão apresenta entrada com resistor interno interrompido.	O teste localizou circuito aberto no resistor da entrada de tensão do módulo de medição.	Reparar ou substituir o módulo


Lote 22 — mecânica
ID	Texto A	Texto B	Reparo principal
M337	O parafuso de potência apresenta porca com rosca desgastada e folga axial excessiva.	A medição confirmou desgaste na porca do fuso de acionamento, com folga acima da tolerância.	Substituir os componentes desgastados
M338	O acoplamento apresenta cubo trincado junto ao rasgo de chaveta.	A inspeção confirmou fissura no cubo do acoplamento na região do alojamento da chaveta.	Substituir o cubo
M339	A transmissão apresenta corrente montada com número de elos incompatível com o projeto.	A conferência identificou comprimento incorreto da corrente por quantidade inadequada de elos.	Instalar a corrente especificada
M340	O rolamento apresenta espaçador entre anéis montado com espessura incorreta.	A medição confirmou espaçador incompatível com o ajuste previsto para o conjunto de rolamentos.	Corrigir a montagem e conferir ajustes
M341	A bomba apresenta impulsor montado com folga radial de funcionamento abaixo do mínimo especificado.	A verificação dimensional confirmou folga radial insuficiente entre o impulsor e a parte estacionária da bomba.	Corrigir o ajuste e avaliar componentes
M342	A válvula apresenta obturador instalado com orientação contrária à especificada.	A conferência de montagem confirmou inversão do elemento de fechamento da válvula.	Corrigir a montagem
M343	A tubulação apresenta junta com diâmetro interno inferior ao especificado, invadindo a passagem do fluido.	A vedação instalada restringe o escoamento porque sua abertura interna é menor que a prevista para a união.	Instalar a junta correta
M344	O suporte da tubulação apresenta placa de deslizamento desgastada abaixo da espessura mínima.	A medição confirmou desgaste excessivo no elemento deslizante do apoio da tubulação.	Substituir a placa e verificar o apoio
M345	O cilindro hidráulico apresenta pistão montado com anel-guia de dimensão incorreta.	A conferência confirmou elemento de guiamento incompatível com a montagem especificada do pistão hidráulico.	Instalar o componente correto
M346	A válvula pneumática apresenta tampa com junta rompida e vazamento externo de ar.	A perda de ar foi localizada na vedação danificada da tampa da válvula pneumática.	Substituir a junta
M347	O conjunto hidráulico apresenta mangueira com terminal em contato e atrito com uma parte móvel.	A montagem permite que o terminal da mangueira hidráulica roce em um componente em movimento.	Corrigir o percurso e avaliar danos
M348	A bomba de graxa apresenta acoplamento de acionamento com elemento rompido.	A transmissão de movimento à bomba de graxa foi interrompida pela ruptura do elemento do acoplamento.	Substituir o elemento e verificar o conjunto
M349	O transportador apresenta rolete montado com eixo sem engajamento suficiente no suporte.	A instalação do rolete deixou comprimento de apoio do eixo inferior ao previsto.	Corrigir a montagem
M350	O carro apresenta suporte de guia com solda fraturada.	A união soldada que fixa a guia do carro ao suporte está rompida.	Recuperar conforme avaliação técnica
M351	A proteção apresenta alça de manuseio com fixação fraturada.	A inspeção confirmou ruptura dos elementos que prendem a alça à proteção.	Recuperar ou substituir a fixação
M352	O mecanismo apresenta seguidor de came montado fora da posição axial especificada.	A conferência confirmou desalinhamento axial do seguidor em relação à pista do came.	Corrigir a montagem


Lote 23 — elétrica
ID	Texto A	Texto B	Reparo principal
E353	A bobina do freio apresenta ligação de alimentação configurada para tensão diferente da especificada.	A conexão instalada na bobina do freio é incompatível com sua tensão nominal.	Corrigir a ligação e avaliar danos
E354	O cabo do motor apresenta prensa-cabo frouxo, permitindo tração indevida sobre os terminais elétricos.	A falta de retenção no prensa-cabo transfere esforços do cabo de alimentação às conexões do motor.	Corrigir a fixação e verificar terminais
E355	O transformador apresenta conexão de fase ligada à derivação de outro enrolamento em desacordo com o projeto.	A conferência identificou ligação incorreta entre terminais dos enrolamentos do transformador.	Corrigir as conexões
E356	O banco de aquecimento apresenta elemento com potência nominal diferente da especificada para a tensão de serviço.	A conferência identificou resistência de aquecimento com potência incompatível com o projeto na tensão utilizada.	Instalar o elemento correto
E357	O contato da chave de teste apresenta resistência elevada por oxidação das superfícies condutoras.	O ensaio confirmou contato resistivo excessivo associado à oxidação na chave de teste.	Recuperar ou substituir a chave
E358	O terminal do circuito de disparo apresenta filamentos soltos em contato com borne adjacente.	A terminação defeituosa do comando de disparo provoca ligação indevida entre bornes vizinhos.	Refazer a terminação e verificar danos
E359	A ligação de aterramento do gabinete apresenta parafuso rompido e terminal desprendido.	O terminal de proteção se soltou da carcaça porque seu parafuso de fixação fraturou.	Recuperar a conexão de proteção
E360	O circuito de sinalização do painel apresenta condutor ligado a uma tensão incompatível com o sinalizador.	A conferência confirmou alimentação incorreta do sinalizador devido à ligação em um ponto de tensão inadequada.	Corrigir a ligação e avaliar danos
E361	O cabo do barramento contínuo apresenta conexão com polaridade invertida no módulo.	Os condutores positivo e negativo do barramento foram trocados nos terminais do módulo.	Corrigir a ligação e avaliar danos
E362	O transformador de alimentação do driver apresenta secundário eletricamente aberto.	O ensaio confirmou interrupção no enrolamento secundário do transformador que alimenta o driver.	Substituir o transformador ou conjunto
E363	O circuito de descarga apresenta contator com bobina eletricamente aberta.	O teste confirmou interrupção na bobina do contator que comanda a descarga do circuito.	Substituir a bobina ou contator
E364	O terminal do indutor de potência apresenta solda rompida e continuidade intermitente.	O ensaio localizou falha de conexão na união soldada do terminal do indutor de potência.	Recuperar ou substituir o conjunto
E365	O sensor óptico apresenta cabo com alimentação e saída trocadas no conector.	A conferência confirmou inversão dos fios de alimentação e sinal no conector do sensor óptico.	Corrigir a ligação e avaliar danos
E366	O módulo de aquisição apresenta referência elétrica desconectada no terminal comum.	A aquisição perdeu sua conexão de referência porque o condutor do borne comum se soltou.	Restabelecer a conexão
E367	O contato da chave de seleção de faixa está eletricamente aberto em uma posição.	O teste confirmou ausência de continuidade na posição correspondente a uma faixa da chave seletora.	Substituir ou recuperar a chave
E368	O circuito do transmissor apresenta componente de proteção contra polaridade reversa eletricamente aberto.	O ensaio localizou interrupção no componente de proteção da entrada de alimentação do transmissor.	Substituir o componente ou conjunto


Lote 23 — mecânica
ID	Texto A	Texto B	Reparo principal
M353	O eixo apresenta superfície de ajuste da polia desgastada abaixo da tolerância.	A medição confirmou diâmetro insuficiente por desgaste no assento da polia no eixo.	Recuperar ou substituir o eixo
M354	A engrenagem apresenta fixação axial com anel de retenção deformado.	O anel que posiciona axialmente a engrenagem perdeu sua geometria e não mantém o travamento previsto.	Substituir e verificar o alojamento
M355	A transmissão apresenta correias de comprimentos incompatíveis no mesmo conjunto de polias.	A conferência identificou correias com comprimentos diferentes dos previstos para o conjunto de transmissão.	Instalar o jogo especificado
M356	O mancal apresenta tampa com superfície de assentamento danificada por rebarba.	Uma rebarba na união impede o assentamento correto da tampa no corpo do mancal.	Recuperar a superfície e conferir o ajuste
M357	A bomba apresenta selo mecânico montado com compressão axial fora da especificação.	A medição de montagem confirmou ajuste incorreto da compressão do selo mecânico da bomba.	Corrigir a montagem e avaliar o selo
M358	A válvula apresenta haste montada com porca de travamento ausente.	A montagem da haste está sem a contraporca especificada para manter seu ajuste.	Instalar o componente e regular
M359	A tubulação apresenta flange montado com faces fora de paralelismo acima do limite.	A verificação dimensional confirmou desalinhamento angular excessivo entre as faces da união flangeada.	Corrigir o alinhamento
M360	O suporte da tubulação apresenta batente lateral rompido.	A inspeção confirmou ruptura do elemento que limita o deslocamento lateral da tubulação no apoio.	Recuperar ou substituir o batente
M361	O cilindro pneumático apresenta tampa com alojamento da vedação danificado.	A inspeção identificou dano na ranhura que recebe o anel vedante da tampa do cilindro pneumático.	Recuperar ou substituir a tampa
M362	A válvula hidráulica apresenta corpo deformado por aperto de montagem excessivo.	A aplicação de torque acima do especificado deformou o corpo da válvula hidráulica.	Substituir ou recuperar conforme avaliação
M363	O conjunto pneumático apresenta tubo inserido sem profundidade suficiente na conexão de engate.	A montagem deixou o tubo de ar parcialmente encaixado, abaixo da inserção exigida na conexão.	Corrigir a montagem e avaliar componentes
M364	O reservatório hidráulico apresenta chapa defletora interna desprendida.	A inspeção confirmou perda de fixação do defletor no interior do tanque hidráulico.	Recuperar a fixação e inspecionar o reservatório
M365	O transportador apresenta tambor com revestimento de espessura abaixo do mínimo permitido.	A medição confirmou desgaste excessivo da camada de revestimento do tambor.	Recompor ou substituir o revestimento
M366	O carro apresenta trilho com junta de união desnivelada além da tolerância.	A verificação confirmou diferença excessiva de altura entre dois segmentos consecutivos do trilho do carro.	Corrigir o alinhamento e a fixação
M367	A proteção apresenta dobradiça com bucha ausente.	A articulação da proteção foi montada sem a bucha prevista entre o pino e o corpo da dobradiça.	Instalar a bucha e avaliar danos
M368	O mecanismo apresenta cabo de aço com fixação ao tambor frouxa.	A ancoragem do cabo no tambor perdeu aperto e não mantém a retenção especificada.	Recompor a fixação e avaliar o cabo


Lote 24 — elétrica
ID	Texto A	Texto B	Reparo principal
E369	A bobina do atuador eletromagnético apresenta resistência abaixo da faixa especificada por curto entre espiras confirmado.	O ensaio confirmou curto entre espiras no atuador eletromagnético, com redução da resistência do enrolamento.	Substituir ou recuperar a bobina
E370	O terminal do motor apresenta conexão com arruela isolante inserida indevidamente entre superfícies condutoras.	A montagem do terminal do motor contém uma peça isolante que impede o contato elétrico previsto.	Corrigir a montagem
E371	O transformador apresenta cabo de ligação secundária com terminal frouxo e aquecimento confirmado.	O aquecimento na saída secundária foi localizado na conexão mal apertada do cabo do transformador.	Refazer a conexão e avaliar danos
E372	O circuito do aquecedor apresenta contator com um contato de potência soldado.	O aquecimento permanece ligado em um polo porque o contato principal do contator está soldado.	Substituir o contator ou conjunto
E373	O circuito da bobina de mínima tensão apresenta cabo eletricamente interrompido.	O teste localizou um condutor rompido na alimentação da bobina de mínima tensão.	Reparar ou substituir o cabo
E374	O relé de supervisão apresenta alimentação ligada em tensão diferente da nominal permitida.	A conferência confirmou tensão de alimentação incompatível com a especificação do relé de supervisão.	Corrigir a alimentação e avaliar danos
E375	A ligação de proteção do painel apresenta condutor com seção inferior à especificada no projeto.	O cabo de aterramento instalado no painel tem seção menor que a prevista no dimensionamento aprovado.	Instalar o condutor especificado
E376	O borne de passagem apresenta ligação interna entre as duas faces eletricamente interrompida.	O teste confirmou perda de continuidade na conexão interna do borne de passagem.	Substituir o borne
E377	O driver apresenta saída de comando eletronicamente em curto.	O ensaio confirmou curto interno no estágio de saída do driver de potência.	Substituir o driver ou placa
E378	O circuito de medição do barramento apresenta cabo de sinal interrompido.	A perda da leitura do barramento foi localizada em um fio rompido no cabo de medição.	Reparar ou substituir o cabo
E379	O resistor de pré-carga apresenta valor de resistência incompatível com a especificação após substituição incorreta.	A conferência identificou resistor de pré-carga com valor ôhmico diferente do previsto no projeto.	Instalar o componente correto
E380	O capacitor de potência apresenta conexão de um terminal com polaridade invertida em relação à marcação especificada.	A montagem do capacitor polarizado contraria a indicação dos terminais positivo e negativo.	Corrigir a montagem e avaliar o componente
E381	O sensor indutivo apresenta estágio de saída permanentemente conduzindo por defeito eletrônico.	O ensaio confirmou saída travada em condução no circuito eletrônico do sensor indutivo.	Substituir o sensor
E382	O transmissor apresenta terminal de alimentação carbonizado e contato intermitente.	A alimentação do transmissor falha na conexão queimada de seu borne.	Recuperar ou substituir os componentes
E383	O módulo de comunicação apresenta conector com contato de sinal oxidado e resistência elevada.	O ensaio localizou contato resistivo excessivo no terminal oxidado do conector de comunicação.	Recuperar ou substituir o conector
E384	O circuito da chave de segurança apresenta jumper indevido entre dois terminais, contrariando o esquema aprovado.	A conferência identificou ponte elétrica não prevista na ligação da chave de segurança.	Recompor o circuito conforme projeto


Lote 24 — mecânica
ID	Texto A	Texto B	Reparo principal
M369	O rolamento apresenta anel externo girando no mancal por perda do ajuste de fixação.	O alojamento não retém o anel externo do rolamento devido ao ajuste inadequado confirmado.	Recuperar o ajuste e avaliar componentes
M370	A polia apresenta face lateral deformada e interferência com a correia.	O empenamento da lateral da polia provoca contato indevido com a correia.	Substituir ou recuperar conforme especificação
M371	A corrente apresenta emenda montada com trava em orientação contrária à especificada.	A conferência confirmou posicionamento incorreto do elemento de retenção do elo de emenda.	Corrigir a montagem e verificar o elo
M372	O acoplamento apresenta elemento flexível montado sem os espaçadores previstos.	A montagem do elemento flexível do acoplamento está sem as peças de espaçamento especificadas.	Corrigir a montagem e avaliar danos
M373	A bomba apresenta anel de vedação montado torcido no alojamento.	A inspeção confirmou torção do anel vedante durante sua instalação na bomba.	Substituir e corrigir a montagem
M374	A válvula apresenta sede montada fora do alojamento especificado.	O elemento de assentamento do obturador está deslocado de sua posição prevista no corpo da válvula.	Corrigir a montagem e avaliar componentes
M375	A tubulação apresenta conexão roscada com vedante aplicado em excesso, obstruindo a passagem.	O material de vedação excedente invade o interior da conexão e restringe o fluxo na tubulação.	Refazer a união e remover os resíduos
M376	O apoio da tubulação apresenta placa de base sem contato uniforme com a fundação.	A inspeção confirmou apoio irregular da base do suporte sobre a superfície de instalação.	Corrigir o assentamento
M377	O cilindro hidráulico apresenta haste com terminal roscado fraturado.	A inspeção confirmou ruptura da extremidade roscada da haste hidráulica.	Substituir a haste ou conjunto
M378	O regulador pneumático apresenta mola de ajuste deformada permanentemente.	A inspeção confirmou perda da geometria especificada da mola de regulagem de pressão de ar.	Substituir a mola ou regulador
M379	A válvula hidráulica apresenta junta entre corpo e placa montada com furação incompatível.	A vedação instalada bloqueia passagens porque seus furos não correspondem aos canais da interface hidráulica.	Instalar a junta correta
M380	A bomba de lubrificação apresenta eixo de acionamento fraturado.	A inspeção confirmou ruptura do eixo que transmite movimento à bomba de lubrificante.	Substituir e investigar a causa
M381	O transportador apresenta rolete com corpo tubular perfurado por desgaste.	A inspeção confirmou perda de espessura com abertura de um furo no tubo do rolete.	Substituir o rolete
M382	O carro apresenta suporte de roda com furo de eixo desgastado além da tolerância.	A medição confirmou desgaste excessivo no alojamento do eixo da roda no suporte do carro.	Recuperar ou substituir o suporte
M383	A proteção apresenta limitador de abertura com cabo rompido.	A ruptura do cabo eliminou a limitação mecânica prevista para a abertura da proteção.	Substituir e verificar o conjunto
M384	O mecanismo apresenta alavanca com trinca junto ao furo de articulação.	A inspeção confirmou fissura na alavanca na região de montagem do pino.	Substituir ou recuperar conforme avaliação


Lote 25 — elétrica
ID	Texto A	Texto B	Reparo principal
E385	O enrolamento do motor apresenta sensor térmico ligado aos terminais de potência por erro de montagem.	A conferência identificou os fios do sensor térmico conectados indevidamente à alimentação de potência do motor.	Corrigir a ligação e avaliar danos
E386	A bobina do freio apresenta terminal de alimentação rompido externamente.	A continuidade da alimentação do freio foi perdida por fratura de um terminal externo da bobina.	Substituir ou recuperar conforme especificação
E387	O transformador apresenta isolador de terminal secundário com perda de isolamento para a tampa.	O ensaio confirmou fuga elétrica do terminal secundário para a tampa metálica através do isolador comprometido.	Substituir o isolador ou conjunto
E388	O banco de resistências apresenta distância de isolamento insuficiente por montagem incorreta dos elementos.	A conferência confirmou espaçamento entre partes condutoras abaixo do previsto na montagem do banco resistivo.	Corrigir a montagem e avaliar danos
E389	O circuito de comando apresenta ligação de contato normalmente aberto onde o projeto exige normalmente fechado.	O cabo de comando foi terminado no contato incorreto em relação à função especificada no esquema.	Corrigir a ligação
E390	O disjuntor apresenta cabo flexível interno com isolamento danificado e fuga para a estrutura.	O ensaio localizou perda de isolamento no condutor interno do disjuntor em relação à sua estrutura metálica.	Substituir ou recuperar conforme especificação
E391	O circuito de proteção apresenta transformador de corrente ligado com polaridade contrária à especificada.	A conferência confirmou inversão de polaridade na ligação do transformador de corrente ao circuito de proteção.	Corrigir a ligação
E392	O borne de proteção apresenta contato com a barra de montagem interrompido por peça quebrada.	A ruptura do contato de encaixe eliminou a continuidade entre o borne de terra e sua barra de montagem.	Substituir o borne
E393	O circuito de potência apresenta terminal do resistor de frenagem ligado ao ponto incorreto do acionamento.	A conferência identificou conexão do resistor de frenagem em borne diferente do previsto no acionamento.	Corrigir a ligação e avaliar danos
E394	A placa de potência apresenta trilha com curto para outra trilha por ponte indevida de solda.	O ensaio confirmou curto entre dois caminhos condutores da placa causado por excesso de solda na montagem.	Recuperar ou substituir a placa
E395	O circuito de alimentação do retificador apresenta contator com contato de potência que não fecha.	O mecanismo do contator atua, mas um contato principal permanece aberto e interrompe a entrada do retificador.	Substituir ou recuperar o conjunto
E396	O filtro de saída apresenta ligação de aterramento do invólucro desconectada.	O filtro perdeu a conexão de proteção de sua carcaça porque o condutor de aterramento se soltou.	Restabelecer a ligação
E397	O sensor de pressão apresenta circuito eletrônico de proteção da alimentação em curto.	O diagnóstico localizou curto interno na proteção da entrada de alimentação do sensor de pressão.	Substituir ou reparar o sensor
E398	O cabo de sinal apresenta emenda com ligação dos condutores trocada em relação ao esquema.	A conferência confirmou inversão dos fios na emenda do cabo de sinal.	Refazer a emenda corretamente
E399	O relé de interface apresenta diodo de proteção interno em curto.	O ensaio confirmou curto no componente interno de supressão conectado à bobina do relé de interface.	Substituir o relé ou componente
E400	O indicador digital apresenta circuito eletrônico de alimentação com saída interna fora da especificação.	O ensaio confirmou falha de regulação na fonte interna do indicador digital.	Reparar ou substituir o indicador


Lote 25 — mecânica
ID	Texto A	Texto B	Reparo principal
M385	O eixo apresenta superfície de vedação com corrosão além do limite de recuperação previsto.	A inspeção confirmou ataque corrosivo excessivo na região do eixo em contato com o vedante.	Substituir ou recuperar conforme avaliação
M386	A engrenagem apresenta face de encosto com rebarba, impedindo o assentamento no eixo.	Uma saliência de material na face da engrenagem impede seu apoio correto no ombro do eixo.	Recuperar a superfície e verificar a montagem
M387	A transmissão apresenta correia torcida na montagem entre as polias.	A inspeção confirmou torção indevida da correia em seu percurso de instalação.	Corrigir a montagem e avaliar a correia
M388	O acoplamento apresenta parafusos de classe mecânica inferior à especificada.	A conferência identificou fixadores com classe de resistência incompatível com o projeto do acoplamento.	Instalar os parafusos especificados
M389	A bomba apresenta carcaça montada com pino de posicionamento ausente.	A montagem do corpo da bomba está sem o pino-guia previsto para seu posicionamento.	Instalar o componente e conferir a montagem
M390	A válvula apresenta haste com rosca cruzada na porca de acionamento.	A união entre haste e porca foi montada incorretamente, danificando o engajamento das roscas.	Recuperar ou substituir os componentes
M391	A tubulação apresenta redução montada em posição diferente da orientação prevista no projeto.	A conferência confirmou orientação incorreta da peça de redução na linha.	Corrigir a montagem
M392	O suporte da tubulação apresenta abraçadeira com dimensão incompatível com o tubo.	A abraçadeira instalada não corresponde ao diâmetro especificado para a tubulação sustentada.	Instalar a abraçadeira correta
M393	O cilindro pneumático apresenta vedação do pistão endurecida e fuga interna de ar.	A perda de flexibilidade do anel vedante do pistão foi associada à passagem indevida de ar entre câmaras.	Substituir e investigar a degradação
M394	A mangueira hidráulica apresenta torção de montagem acima do permitido pelo fabricante.	A instalação deixou a mangueira de óleo torcida além do limite especificado.	Corrigir o percurso e avaliar a mangueira
M395	A válvula pneumática apresenta obturador com superfície de vedação riscada.	A inspeção identificou sulcos na face vedante do elemento de fechamento da válvula de ar.	Recuperar ou substituir o conjunto
M396	O sistema de lubrificação apresenta tubo instalado sem a fixação prevista, permitindo vibração excessiva.	A ausência dos suportes especificados deixa a linha de lubrificante vibrar acima do admissível.	Instalar as fixações e avaliar a linha
M397	O transportador apresenta raspador montado com ângulo diferente do especificado.	A conferência confirmou orientação angular incorreta da lâmina do raspador em relação à correia.	Corrigir a montagem e o ajuste
M398	O carro apresenta trilho com fixador de dimensão incompatível com a ancoragem.	A conferência identificou parafuso incorreto na fixação do trilho do carro.	Instalar o fixador especificado
M399	A proteção apresenta chapa de fechamento com trinca junto à fixação.	A inspeção confirmou fissura na chapa da proteção na região do parafuso de montagem.	Recuperar ou substituir a chapa
M400	O mecanismo apresenta pino de articulação com trava deformada e sem retenção adequada.	A deformação do elemento de travamento compromete a retenção axial do pino do mecanismo.	Substituir a trava e verificar o conjunto

