ID	Texto A	Texto B	Reparo principal
E145	O enrolamento do motor submersível apresenta fuga elétrica para sua carcaça.	O ensaio confirmou perda de isolamento entre a bobina do motor submersível e a estrutura metálica.	Recuperar ou substituir o motor
E146	A conexão elétrica da escova ao seu cabo flexível está rompida.	O cabo flexível perdeu continuidade na união com a escova.	Substituir a escova com sua ligação
E147	O transformador de comando apresenta curto entre o enrolamento primário e o secundário.	O ensaio confirmou perda de isolamento entre os dois enrolamentos do transformador de comando.	Recuperar ou substituir o transformador
E148	A resistência de aquecimento foi ligada em tensão superior à especificada por erro de conexão.	A ligação instalada alimenta o aquecedor com tensão acima de seu valor nominal.	Corrigir a ligação e avaliar o aquecedor
E149	O contato de saída do relé de proteção está soldado.	A saída do relé de proteção permanece fechada por soldagem dos contatos.	Substituir o relé ou conjunto
E150	O terminal de neutro está carbonizado e apresenta mau contato confirmado.	A conexão defeituosa foi localizada no borne de neutro carbonizado.	Substituir os componentes danificados
E151	O circuito de indicação de posição do disjuntor está interrompido por fio rompido.	Um condutor partido impede a continuidade do sinal de posição do disjuntor.	Reparar ou substituir o condutor
E152	O isolador de passagem do painel apresenta descarga superficial por contaminação condutiva.	Os resíduos condutivos sobre a bucha de passagem provocam descargas em sua superfície.	Limpar ou substituir conforme avaliação
E153	O diodo do circuito de pré-carga apresenta curto interno.	O ensaio identificou curto-circuito no diodo utilizado na pré-carga.	Substituir o diodo
E154	O circuito de comando do chopper não fornece pulsos por defeito eletrônico confirmado.	A ausência dos pulsos de frenagem foi localizada na eletrônica de comando do chopper.	Reparar ou substituir a placa
E155	O cabo de saída do inversor apresenta curto entre uma fase e o condutor de proteção.	O ensaio localizou curto elétrico entre um fio de fase e o fio de proteção no cabo do inversor.	Substituir o trecho
E156	O circuito de sincronismo do retificador está danificado e não detecta a referência de fase.	A referência de fase não é reconhecida devido a defeito na eletrônica de sincronismo do retificador.	Reparar ou substituir a placa
E157	O sensor ultrassônico recebe alimentação correta, mas sua eletrônica de saída está danificada.	O teste confirmou defeito na saída eletrônica do sensor ultrassônico, com alimentação normal.	Substituir o sensor
E158	O cabo da chave de segurança apresenta condutor de sinal rompido.	A perda de continuidade do sinal de segurança foi localizada no cabo da chave.	Substituir ou reparar conforme especificação
E159	O módulo de termopares apresenta circuito de compensação de junta fria danificado.	O ensaio confirmou falha eletrônica na compensação de junta fria do módulo de termopares.	Reparar ou substituir o módulo
E160	O terminal de alimentação do switch industrial está frouxo e causa interrupções elétricas.	A alimentação intermitente do switch foi localizada em um condutor mal apertado no borne.	Refazer a conexão


Lote 10 — mecânica
ID	Texto A	Texto B	Reparo principal
M145	A corrente apresenta placa lateral de um elo fraturada.	A inspeção confirmou ruptura da chapa lateral de um elo da corrente.	Substituir os componentes conforme especificação
M146	O rolamento apresenta corrosão nas pistas acima do limite admissível.	A inspeção identificou ataque corrosivo excessivo nas superfícies de rolamento.	Substituir o rolamento
M147	O eixo do redutor apresenta assento de rolamento desgastado abaixo da tolerância.	A medição confirmou diâmetro insuficiente no assento do rolamento do eixo do redutor.	Recuperar ou substituir o eixo
M148	O acoplamento apresenta espaçamento axial de montagem fora da especificação.	A distância entre os cubos do acoplamento foi ajustada fora do intervalo permitido.	Corrigir a montagem
M149	A bomba apresenta anel de retenção do impulsor ausente.	O impulsor está sem o anel responsável por sua retenção axial.	Instalar o elemento especificado
M150	A válvula de água apresenta guia da haste desgastada, com folga excessiva.	A folga lateral da haste foi localizada no desgaste de sua guia.	Substituir ou recuperar os componentes
M151	A junta de expansão metálica apresenta tirante limitador fraturado.	A inspeção confirmou ruptura de um tirante de limitação da junta de expansão.	Substituir e verificar o conjunto
M152	A flange da bomba apresenta parafuso de fixação fraturado.	A união flangeada da bomba perdeu um elemento de fixação por ruptura do parafuso.	Substituir e verificar a união
M153	O cilindro hidráulico apresenta olhal de fixação trincado.	A inspeção confirmou fissura no olhal de montagem do cilindro hidráulico.	Substituir ou recuperar conforme avaliação
M154	A válvula pneumática apresenta mola de retorno fraturada.	O retorno do mecanismo da válvula pneumática foi comprometido pela ruptura da mola.	Substituir a mola ou conjunto
M155	O distribuidor de graxa apresenta êmbolo mecanicamente travado por resíduos.	Os resíduos bloquearam o deslocamento do êmbolo no distribuidor de lubrificação.	Limpar ou substituir conforme diagnóstico
M156	O suporte do acumulador hidráulico está fraturado.	A inspeção identificou ruptura no suporte que fixa o acumulador hidráulico.	Substituir ou recuperar o suporte
M157	O rolete apresenta tampa lateral desprendida por ruptura da fixação.	A fixação rompida deixou a tampa lateral do rolete solta.	Recuperar ou substituir o conjunto
M158	O transportador apresenta corrente com tensionamento abaixo do especificado por regulagem incorreta.	A regulagem inadequada deixou a corrente do transportador excessivamente frouxa.	Corrigir o tensionamento
M159	O trilho apresenta fixadores soltos e permite deslocamento lateral.	O trilho se movimenta lateralmente porque seus elementos de fixação perderam aperto.	Restabelecer a fixação
M160	A proteção apresenta tela metálica rompida.	A inspeção identificou abertura por ruptura na tela da proteção.	Substituir ou recuperar conforme especificação


Lote 11 — elétrica
ID	Texto A	Texto B	Reparo principal
E161	O enrolamento do motor apresenta ligação interna de fase executada incorretamente.	A conferência confirmou conexão interna dos enrolamentos diferente do esquema previsto.	Corrigir a ligação
E162	O terminal do banco de resistências está frouxo e provoca centelhamento.	O arco na conexão do banco resistivo foi associado à falta de aperto do terminal.	Refazer a conexão
E163	O circuito de excitação do gerador apresenta fusível aberto, com causa já corrigida.	Após corrigir a causa da atuação, o fusível de excitação do gerador permanece interrompido.	Substituir o fusível especificado
E164	A ligação de proteção do motor está presa sobre pintura e não estabelece continuidade adequada.	A camada de tinta sob o terminal impede o contato elétrico correto do aterramento do motor.	Recompor a conexão conforme especificação
E165	O contato de um polo do disjuntor permanece fechado por soldagem.	O ensaio confirmou contatos soldados em um polo do disjuntor, impedindo sua abertura.	Substituir o conjunto
E166	O circuito de alimentação do relé de proteção está aberto por terminal desconectado.	A ausência de alimentação do relé foi localizada em um terminal solto e desconectado.	Restabelecer a ligação
E167	A ponte de ligação entre bornes está eletricamente rompida.	A distribuição de tensão foi interrompida por ruptura da ponte metálica da régua de bornes.	Substituir a ponte
E168	A conexão do para-raios ao aterramento está interrompida por ruptura do cabo.	O para-raios perdeu sua ligação ao terra porque o condutor rompeu.	Substituir o condutor
E169	O capacitor do filtro de saída do inversor apresenta falha de isolamento para sua carcaça.	O ensaio confirmou fuga elétrica entre o capacitor do filtro de saída e seu invólucro metálico.	Substituir o capacitor
E170	O circuito de medição da tensão de entrada do conversor está danificado.	A eletrônica de aquisição da tensão de alimentação do conversor apresenta defeito confirmado.	Reparar ou substituir a placa
E171	O terminal da bateria do nobreak está desconectado e interrompe sua alimentação de reserva.	O nobreak perdeu a conexão com a bateria porque seu terminal se desprendeu.	Restabelecer e verificar a conexão
E172	O enrolamento do reator de saída apresenta curto entre espiras.	O ensaio confirmou curto entre espiras da bobina do reator instalado na saída do conversor.	Recuperar ou substituir o reator
E173	O contato do pressostato apresenta resistência elevada quando fechado.	O ensaio confirmou resistência de contato excessiva no pressostato acionado.	Substituir o contato ou conjunto
E174	O cabo do sensor apresenta contato intermitente em um pino oxidado do conector.	A oxidação de um terminal do conector provoca interrupções na ligação elétrica do sensor.	Recuperar ou substituir o conector
E175	O módulo de comunicação do CLP apresenta transceptor eletrônico danificado.	O teste localizou a falha de comunicação no circuito transceptor do módulo do CLP.	Reparar ou substituir o módulo
E176	A fonte do instrumento apresenta entrada ligada em tensão incompatível com sua especificação.	A alimentação instalada na fonte do instrumento tem tensão diferente da nominal permitida.	Corrigir a alimentação e avaliar danos


Lote 11 — mecânica
ID	Texto A	Texto B	Reparo principal
M161	A polia apresenta trinca em um de seus raios estruturais.	A inspeção confirmou fissura no elemento que liga o cubo ao aro da polia.	Substituir a polia
M162	O acoplamento apresenta pino de transmissão fraturado.	A transmissão de torque foi interrompida pela ruptura de um pino do acoplamento.	Substituir e verificar o conjunto
M163	A corrente apresenta pino de elo com desgaste acima da tolerância.	A medição confirmou redução excessiva do diâmetro de um pino da corrente.	Substituir os componentes conforme especificação
M164	O redutor apresenta pré-carga de rolamentos acima da especificação por ajuste incorreto.	O ajuste de montagem aplicou pré-carga excessiva aos rolamentos do redutor.	Corrigir o ajuste e avaliar danos
M165	A tampa da bomba apresenta trinca estrutural.	A inspeção confirmou fissura no corpo da tampa da bomba.	Substituir ou recuperar conforme avaliação
M166	A válvula apresenta volante fraturado.	O comando manual da válvula está comprometido pela ruptura do volante.	Substituir o volante
M167	A tubulação apresenta junta montada fora de posição, com vazamento confirmado.	A vedação da união falhou porque a junta foi instalada deslocada do assentamento.	Corrigir a montagem e substituir a junta
M168	O suporte da tubulação apresenta elemento deslizante mecanicamente travado por corrosão.	A corrosão bloqueou o deslizamento previsto no apoio da tubulação.	Recuperar ou substituir o apoio
M169	O cilindro hidráulico apresenta guia da haste desgastada, com folga radial excessiva.	A medição confirmou desgaste acima da tolerância na bucha de guia da haste hidráulica.	Substituir a guia e inspecionar a haste
M170	O conjunto pneumático apresenta suporte de fixação deformado.	A base que sustenta o conjunto de tratamento de ar está empenada.	Recuperar ou substituir o suporte
M171	O reservatório hidráulico apresenta tampa de inspeção com junta rompida e vazamento.	A perda de óleo foi localizada na junta danificada da tampa de inspeção do reservatório.	Substituir a junta
M172	A linha de lubrificação apresenta conexão solta e vazamento de graxa.	A graxa escapa por uma união da linha que perdeu aperto.	Recompor a conexão
M173	O transportador apresenta tambor montado fora de alinhamento.	A verificação geométrica confirmou desalinhamento do tambor em relação à estrutura do transportador.	Corrigir o alinhamento
M174	O carro apresenta eixo de roda empenado acima da tolerância.	A medição confirmou deformação excessiva no eixo de uma roda do carro.	Recuperar ou substituir o eixo
M175	A proteção articulada apresenta batente de apoio ausente.	A proteção está sem o elemento de apoio que limita sua posição de fechamento.	Instalar o batente especificado
M176	A articulação apresenta pino montado sem o elemento de lubrificação previsto.	O ponto de articulação está sem o bico de lubrificação especificado para o pino.	Instalar o componente e verificar a lubrificação


Lote 12 — elétrica
ID	Texto A	Texto B	Reparo principal
E177	O enrolamento do motor apresenta conexão interna com solda rompida.	A continuidade da bobina foi interrompida na união soldada interna do motor.	Recuperar a conexão
E178	O terminal do resistor de aterramento apresenta isolamento danificado e fuga para a estrutura.	O ensaio confirmou passagem indevida de corrente do terminal do resistor de aterramento para seu suporte metálico.	Recompor a isolação ou substituir o conjunto
E179	O aquecedor elétrico apresenta ligação de elementos em série onde o projeto exige paralelo.	A montagem elétrica do aquecedor usa associação em série incompatível com o esquema previsto em paralelo.	Corrigir a ligação
E180	O cabo do gerador apresenta blindagem de proteção desconectada do aterramento previsto.	A ligação ao terra da blindagem do cabo de saída do gerador está interrompida no terminal.	Restabelecer a conexão
E181	O dispositivo diferencial residual não atua no ensaio elétrico, apesar das condições corretas de teste.	O teste funcional confirmou falha de disparo do dispositivo diferencial residual.	Substituir o dispositivo
E182	O circuito da bobina de disparo apresenta contato de teste eletricamente aberto em posição de serviço.	A continuidade do comando de disparo foi perdida no contato de teste que deveria estar fechado em serviço.	Recuperar ou substituir o contato
E183	A chave reversora apresenta ligação de fases incompatível com o esquema aprovado.	A conferência identificou conexão incorreta de fases nos terminais da chave reversora.	Corrigir as ligações
E184	O terminal de proteção da tomada industrial está desconectado internamente.	A tomada perdeu continuidade no contato de aterramento devido à desconexão interna do condutor.	Recuperar ou substituir a tomada
E185	O tiristor do circuito de potência está eletricamente aberto.	O ensaio confirmou interrupção interna no tiristor do estágio de potência.	Substituir o componente
E186	O circuito eletrônico de comando do ventilador do inversor está danificado.	A ausência de acionamento do ventilador foi localizada em falha eletrônica da placa de comando do inversor.	Reparar ou substituir a placa
E187	O barramento contínuo apresenta conexão aparafusada com resistência elétrica elevada.	O ensaio localizou resistência excessiva em uma união parafusada do barramento de corrente contínua.	Refazer a conexão e avaliar danos
E188	O filtro de interferência apresenta capacitor com curto interno confirmado.	O ensaio identificou curto-circuito em um capacitor do filtro de interferência elétrica.	Substituir o componente ou filtro
E189	O sensor de temperatura com saída de corrente apresenta circuito transmissor danificado.	O teste confirmou defeito na eletrônica que converte a temperatura em sinal de corrente no sensor.	Substituir ou reparar o sensor
E190	O contato do seletor de modo permanece fechado por soldagem.	A chave de seleção de modo mantém continuidade indevida porque seu contato está soldado.	Substituir o bloco de contato
E191	O circuito de alimentação do módulo remoto apresenta fusível aberto, com causa já corrigida.	Após corrigir a causa da atuação, permanece interrompido o fusível que alimenta o módulo remoto.	Substituir o fusível especificado
E192	O cabo da célula de carga apresenta curto entre um condutor de excitação e um de sinal.	O ensaio localizou contato elétrico indevido entre os fios de alimentação e de sinal da célula de carga.	Substituir ou reparar o cabo


Lote 12 — mecânica
ID	Texto A	Texto B	Reparo principal
M177	O rolamento apresenta anel externo fraturado.	A inspeção confirmou ruptura do anel externo do rolamento.	Substituir o rolamento
M178	A engrenagem está montada com folga na fixação ao eixo por porca solta.	A porca de retenção afrouxou e deixou a engrenagem sem a fixação especificada no eixo.	Restabelecer a fixação e avaliar danos
M179	A correia de transmissão apresenta tensão acima da especificação por regulagem incorreta.	O ajuste do tensionador deixou a correia excessivamente tensionada.	Corrigir o tensionamento
M180	O acoplamento apresenta desalinhamento angular acima da tolerância.	A medição confirmou ângulo excessivo entre os eixos unidos pelo acoplamento.	Corrigir o alinhamento
M181	A bomba apresenta folga axial do rotor fora da tolerância por ajuste incorreto.	A montagem deixou o deslocamento axial do rotor da bomba acima do limite previsto.	Corrigir o ajuste
M182	A válvula apresenta mola de fechamento fraturada.	A inspeção confirmou ruptura da mola que aplica força de fechamento à válvula.	Substituir a mola ou conjunto
M183	O tubo apresenta trinca junto à união soldada, com vazamento de água.	A perda de água foi localizada em uma fissura próxima da solda da tubulação.	Substituir ou recuperar conforme avaliação técnica
M184	O flange apresenta parafuso de comprimento incorreto, sem engajamento suficiente da rosca.	A união flangeada foi montada com fixador curto demais para alcançar o engajamento especificado.	Instalar o fixador correto
M185	O cilindro pneumático apresenta haste riscada na região de contato com a vedação.	A inspeção identificou sulcos na superfície da haste pneumática onde atua o elemento vedante.	Recuperar ou substituir a haste
M186	A mangueira hidráulica apresenta terminal prensado com retenção mecânica insuficiente confirmada.	A inspeção constatou falha de prensagem que compromete a fixação do terminal à mangueira hidráulica.	Substituir o conjunto conforme especificação
M187	O filtro hidráulico apresenta tampa com rosca danificada, impedindo o fechamento especificado.	A tampa do filtro de óleo não pode ser fixada corretamente devido ao dano em sua rosca.	Recuperar ou substituir conforme avaliação
M188	A conexão pneumática apresenta anel de vedação ausente.	A união da linha de ar foi montada sem o elemento de vedação especificado.	Instalar a vedação correta
M189	O transportador apresenta chapa lateral deformada e em contato com a correia.	O empenamento da lateral do transportador provoca atrito indevido com a correia.	Recuperar ou substituir a chapa
M190	O carro apresenta raspador de trilho desgastado além do limite.	A inspeção confirmou desgaste excessivo na lâmina que remove resíduos do trilho do carro.	Substituir e ajustar o raspador
M191	A proteção apresenta fecho com mola interna fraturada.	O mecanismo de fechamento da proteção perdeu sua mola interna por ruptura.	Substituir a mola ou fecho
M192	A base do equipamento apresenta calço de apoio fraturado.	A inspeção confirmou ruptura de um calço que sustenta a base do equipamento.	Substituir o calço e verificar o apoio


Lote 13 — elétrica
ID	Texto A	Texto B	Reparo principal
E193	O motor apresenta cabo interno de ligação ao borne com isolamento rompido e fuga para a carcaça.	O ensaio localizou falha de isolação no condutor interno entre o enrolamento e o terminal do motor.	Recuperar a ligação e a isolação
E194	A ligação elétrica do gerador apresenta terminal prensado com contato resistivo excessivo.	A medição confirmou resistência elevada na crimpagem de um terminal de conexão do gerador.	Refazer a terminação
E195	O resistor de aquecimento apresenta curto entre trechos de seu elemento resistivo.	A inspeção confirmou contato elétrico indevido entre segmentos do elemento do aquecedor.	Substituir o elemento
E196	O circuito de alimentação do freio eletromagnético apresenta ponte retificadora com diodo aberto.	O teste identificou interrupção em um diodo do retificador que alimenta a bobina do freio.	Substituir o componente ou conjunto
E197	O circuito de comando apresenta fio de retorno ligado ao borne errado.	A conferência identificou conexão incorreta do condutor de retorno no circuito de comando.	Corrigir a ligação
E198	O contato auxiliar do contator permanece fechado por soldagem.	O contato auxiliar não abre com a bobina desenergizada porque suas superfícies estão soldadas.	Substituir o bloco auxiliar
E199	O relé de monitoramento de tensão apresenta circuito de medição danificado.	O ensaio confirmou defeito na entrada eletrônica de medição do relé de tensão.	Reparar ou substituir o relé
E200	O conector de potência apresenta terminal com revestimento degradado e resistência de contato elevada.	O ensaio confirmou resistência excessiva associada à deterioração do revestimento do contato de potência.	Substituir os contatos comprometidos
E201	A placa de potência apresenta falha de isolamento entre uma trilha energizada e seu ponto de fixação metálico.	O ensaio identificou fuga elétrica da trilha de potência para a fixação metálica da placa.	Substituir ou reparar conforme avaliação
E202	O conversor apresenta enrolamento do transformador de alimentação auxiliar em curto entre espiras.	O ensaio confirmou curto entre espiras no transformador que alimenta os circuitos auxiliares do conversor.	Substituir o transformador ou conjunto
E203	O circuito eletrônico de habilitação do acionamento está danificado e não reconhece o sinal correto de entrada.	O teste confirmou falha na eletrônica de entrada de habilitação, apesar da aplicação do sinal especificado.	Reparar ou substituir a placa
E204	O cabo entre o acionamento e o resistor de frenagem está eletricamente interrompido.	O teste de continuidade confirmou condutor rompido na ligação do resistor de frenagem ao acionamento.	Substituir ou reparar o cabo
E205	O sensor de posição recebe alimentação normal, mas seu circuito de saída em tensão está danificado.	O ensaio confirmou defeito na eletrônica de saída de tensão do sensor de posição, com alimentação adequada.	Substituir ou reparar o sensor
E206	A tomada do instrumento apresenta contato de fase carbonizado e continuidade intermitente.	A alimentação do instrumento falha no contato de fase queimado da tomada.	Substituir a tomada e avaliar a conexão
E207	O circuito do sinalizador luminoso apresenta resistor limitador eletricamente aberto.	O sinalizador não recebe corrente devido à interrupção de seu resistor limitador.	Substituir o resistor ou sinalizador
E208	O módulo de entrada de pulsos apresenta circuito eletrônico de contagem danificado, confirmado por gerador de teste.	A aplicação de pulsos de referência confirmou falha na eletrônica de contagem do módulo.	Reparar ou substituir o módulo


Lote 13 — mecânica
ID	Texto A	Texto B	Reparo principal
M193	O eixo apresenta ombro de encosto desgastado, comprometendo o posicionamento axial do rolamento.	A superfície de apoio axial do rolamento no eixo perdeu material além da tolerância.	Recuperar ou substituir o eixo
M194	A roda dentada está montada fora do plano de alinhamento da corrente.	A verificação confirmou desalinhamento lateral da roda dentada em relação à linha da corrente.	Corrigir o alinhamento
M195	O acoplamento apresenta elemento metálico flexível fraturado.	A inspeção confirmou ruptura do elemento flexível metálico do acoplamento.	Substituir o elemento ou conjunto
M196	O redutor apresenta rolamento montado sem o espaçador axial especificado.	A montagem dos rolamentos da caixa de engrenagens está sem a peça de espaçamento axial prevista.	Corrigir a montagem e avaliar danos
M197	A bomba apresenta obstrução por resíduos no canal de passagem do impulsor.	O acúmulo de material bloqueia uma passagem interna do impulsor da bomba.	Limpar e inspecionar o impulsor
M198	A válvula apresenta anel de retenção do obturador rompido.	A inspeção confirmou ruptura do elemento que mantém o obturador retido no conjunto da válvula.	Substituir e verificar o conjunto
M199	O suporte de tubulação apresenta chapa de base trincada.	A inspeção identificou fissura na placa de apoio do suporte da tubulação.	Recuperar ou substituir conforme avaliação
M200	A junta de flange apresenta espessura incompatível com a especificação de montagem.	A união flangeada foi montada com vedação de espessura diferente da prevista no projeto.	Instalar a junta especificada
M201	O cilindro hidráulico apresenta anel-guia do pistão fraturado.	A inspeção interna confirmou ruptura do elemento que guia o pistão no tubo hidráulico.	Substituir o anel-guia e avaliar superfícies
M202	A válvula pneumática manual apresenta eixo da alavanca desgastado e folga excessiva.	A folga do comando manual foi localizada no desgaste do eixo da alavanca pneumática.	Substituir ou recuperar os componentes
M203	A mangueira de lubrificação está comprimida por uma abraçadeira excessivamente apertada.	O aperto indevido da fixação estrangula a passagem de lubrificante na mangueira.	Corrigir a fixação e avaliar a mangueira
M204	O reservatório hidráulico apresenta respiro obstruído por resíduos.	A passagem de ventilação do tanque de óleo está bloqueada por contaminantes no respiro.	Limpar ou substituir o respiro
M205	O tambor do transportador apresenta eixo com trinca confirmada em ensaio.	O ensaio identificou fissura no eixo do tambor do transportador.	Substituir e investigar a causa
M206	O mecanismo apresenta cabo de aço com terminal de ancoragem deformado.	A inspeção confirmou deformação no terminal que fixa o cabo de aço à ancoragem.	Substituir conforme especificação
M207	A proteção deslizante apresenta guia deformada e fica mecanicamente presa.	O empenamento da guia impede o deslocamento normal da proteção deslizante.	Recuperar ou substituir a guia
M208	A plataforma apresenta parafuso de ancoragem fraturado.	A fixação da plataforma perdeu um de seus elementos por ruptura do parafuso de ancoragem.	Substituir e avaliar a ancoragem

