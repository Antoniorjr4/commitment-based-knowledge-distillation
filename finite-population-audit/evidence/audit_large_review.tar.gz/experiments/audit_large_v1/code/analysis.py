from scipy.stats import hypergeom

N = 2048
SAMPLE_N = 768
DELTA = 0.05
MAX_ACCEPTABLE_TOTAL = 204

def upper_total(k, n=SAMPLE_N):
    if (
        type(k) is not int or type(n) is not int
        or not 1 <= n <= N or not 0 <= k <= n
    ):
        raise ValueError("Invalid counts")
    low, high = k, N - n + k
    while low < high:
        middle = (low + high + 1) // 2
        if hypergeom.cdf(k, N, middle, n) > DELTA:
            low = middle
        else:
            high = middle - 1
    return low

def certificate(k, n=SAMPLE_N):
    total = upper_total(k, n)
    return {
        "N": N,
        "n": n,
        "k": k,
        "delta": DELTA,
        "observed_disagreement": k / n,
        "upper_population_disagreements": total,
        "exact_hypergeometric_upper": total / N,
        "primary_acceptance": (
            total <= MAX_ACCEPTABLE_TOTAL if n == SAMPLE_N else None
        ),
        "census": n == N,
    }
