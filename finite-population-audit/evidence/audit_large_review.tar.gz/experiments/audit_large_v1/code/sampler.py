import hashlib

def sample_order(population_sha256, randomness_hex, size):
    if size < 1:
        raise ValueError("Population must not be empty")
    population_hash = bytes.fromhex(population_sha256)
    randomness = bytes.fromhex(randomness_hex)
    if len(population_hash) != 32 or len(randomness) != 32:
        raise ValueError("Expected 32-byte hashes")
    seed = hashlib.sha256(
        b"anna-audit-large-v1"
        + population_hash
        + randomness
    ).digest()
    counter = 0

    def randbelow(bound):
        nonlocal counter
        space = 1 << 256
        limit = space - space % bound
        while True:
            block = hashlib.sha256(
                seed + counter.to_bytes(8, "big")
            ).digest()
            counter += 1
            value = int.from_bytes(block, "big")
            if value < limit:
                return value % bound

    order = list(range(size))
    for i in range(size - 1, 0, -1):
        j = randbelow(i + 1)
        order[i], order[j] = order[j], order[i]
    return order
