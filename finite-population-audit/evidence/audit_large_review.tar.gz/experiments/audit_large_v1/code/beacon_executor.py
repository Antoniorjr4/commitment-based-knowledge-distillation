import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

import httpx

ROOT = Path("experiments/audit_large_v1")
SETTINGS_HASH = "3b14209b68433d0afcbc1aa8b1fd79c59c5d72df69a71281e6be140ff76b8e19"
CODE_HASH = "499e6e5a2facb541c4c22386f88f4bbfd3eebf93e61da40554e41fde85076b27"
TABLE_HASH = "da46b7264cb88f40571212052d207893cf408f050ee44cb1edaf7d499fcc96d5"
OLD_PLAN_HASH = "c5b60df7b186b42375dd03d88a09fd8d64465edad745001a5aabd9cea7495e48"
CHAIN = "52db9ba70e0cc0f6eaf7803dd07447a1f5477735fd3f661792ba94600c84e971"
BASE = "https://api.drand.sh/" + CHAIN

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def checked(path, expected):
    raw = path.read_bytes()
    if sha(raw) != expected:
        raise RuntimeError(f"Hash diferente: {path}")
    return json.loads(raw)

def save_fixed(path, value):
    text = json.dumps(value, ensure_ascii=False, indent=2)
    if path.exists():
        if path.read_text() != text:
            raise RuntimeError(f"Arquivo existente diferente: {path}")
    else:
        with path.open("x") as file:
            file.write(text)

def verify(beacon, info):
    from py_ecc.bls.g2_primitives import pubkey_to_G1, signature_to_G2
    from py_ecc.bls.hash_to_curve import hash_to_G1
    from py_ecc.optimized_bls12_381 import (
        G2, curve_order, is_inf, multiply, pairing,
    )

    if (
        info["hash"] != CHAIN
        or info["schemeID"] != "bls-unchained-g1-rfc9380"
        or info["period"] != 3
    ):
        raise RuntimeError("Rede drand inesperada.")

    signature = bytes.fromhex(beacon["signature"])
    public_key = bytes.fromhex(info["public_key"])
    if len(signature) != 48 or len(public_key) != 96:
        raise RuntimeError("Tamanho BLS inesperado.")
    if sha(signature) != beacon["randomness"]:
        raise RuntimeError("Randomness incompatível com assinatura.")

    sig_point = pubkey_to_G1(signature)
    key_point = signature_to_G2(public_key)
    for point in (sig_point, key_point):
        if is_inf(point) or not is_inf(multiply(point, curve_order)):
            raise RuntimeError("Ponto BLS inválido.")

    domain = b"BLS_SIG_BLS12381G1_XMD:SHA-256_SSWU_RO_NUL_"
    def matches(round_number):
        message = hashlib.sha256(
            round_number.to_bytes(8, "big")
        ).digest()
        hashed = hash_to_G1(message, domain, hashlib.sha256)
        return pairing(key_point, hashed) == pairing(G2, sig_point)

    if not matches(int(beacon["round"])):
        raise RuntimeError("Assinatura BLS inválida.")
    if matches(int(beacon["round"]) + 1):
        raise RuntimeError("Controle negativo BLS falhou.")

def get_json(url):
    with httpx.Client(timeout=30) as client:
        response = client.get(url)
        if response.status_code in (404, 425):
            raise SystemExit(
                "Rodada ainda indisponível. Execute novamente mais tarde; "
                "não altere a rodada."
            )
        response.raise_for_status()
        return response.json()


ARTIFACTS = {
    "population.json":
        "719f66a571b90bd2cb7429d859b391ca0b66bc177e5c56c63d85f8aab8dd52f3",
    "execution_settings.json":
        "7eee96fd3fba6a6d740ce24a1be85775508ef938a15a8df6d889b425d819c738",
    "student_table.json":
        "d8e79ce6f2bc3586cb08f7e76e18f10c033f484ec863cabbd2047d285d2ff3cf",
    "methods_manifest.json":
        "8f0dba8a0d5ab1dc85bd85cc630f947fcbf32c229f99053c872ad6fa32cbba06",
    "code/student_executor.py":
        "1b9e56b08ea828546feab93ee6ba8037a72691e5b7faefb302e32cef648e2c1b",
    "student_executor_manifest.json":
        "8ed3898db3512d1d026ace7594fa509488d731d3c6e31f82f5f2df97194ecd65",
    "code/teacher_executor.py":
        "7767fc28509ac0a45a99a6bfed1a85339989bceabdb5f2a44f6ef5fe0cea6ea0",
    "teacher_executor_manifest.json":
        "a2324b50e2fdb4ad7f88b612763c27e1a3330495873be988f1bb91fad2c89469",
    "code/sampler.py":
        "547da7f94f5988c4bedcc7455933827b1d70aeedde7bd624d3b2c5e96bd87fb8",
    "code/analysis.py":
        "b8d08b1b290cd7aa6dd6053fae637d07daf6014b99fa81f5624c31fbaccc5486",
}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["prepare", "reserve", "draw"])
    args = parser.parse_args()

    own_hash = sha(Path(__file__).read_bytes())
    for name, expected in ARTIFACTS.items():
        if sha((ROOT / name).read_bytes()) != expected:
            raise RuntimeError(f"Artefato alterado: {name}")

    code_manifest = {
        "beacon_executor_sha256": own_hash,
        "artifact_sha256": ARTIFACTS,
        "verification_origin_sha256":
            "de3bab65062bd64cefd3acc35cfa1f1fd84a9274efffa6463dd9a4d3b6e73890",
        "chain_hash": CHAIN,
        "future_round_offset": 100,
        "N": 2048,
        "n": 768,
    }
    manifest_path = ROOT / "beacon_executor_manifest.json"
    if args.stage == "prepare":
        save_fixed(manifest_path, code_manifest)
        print("VERIFICADOR DO BEACON E SORTEIO FIXADOS")
        print("SHA256 do executor:", own_hash)
        print("SHA256 do manifesto:", sha(manifest_path.read_bytes()))
        print("Nenhuma rodada reservada; nenhuma consulta ao Teacher.")
        return

    if json.loads(manifest_path.read_text()) != code_manifest:
        raise RuntimeError("Executor diferente do preparado.")

    settings = json.loads((ROOT / "execution_settings.json").read_text())
    population = json.loads((ROOT / "population.json").read_text())
    table = json.loads((ROOT / "student_table.json").read_text())
    population_ids = [r["id"] for r in population["rows"]]
    if (
        len(population_ids) != 2048
        or len(set(population_ids)) != 2048
        or [r["id"] for r in table["rows"]] != population_ids
    ):
        raise RuntimeError("Ordem ou identidade da tabela inconsistente.")

    adapter = Path(settings["adapter_path"])
    adapter_hashes = {
        str(p.relative_to(adapter)): sha(p.read_bytes())
        for p in sorted(adapter.rglob("*")) if p.is_file()
    }
    if adapter_hashes != settings["adapter_sha256"]:
        raise RuntimeError("Adapter diferente do congelado.")

    old_plan = checked(
        Path("experiments/audit_v1/randomness_plan.json"), OLD_PLAN_HASH
    )
    info = old_plan["chain_info"]
    if (
        info["hash"] != CHAIN
        or info["schemeID"] != "bls-unchained-g1-rfc9380"
        or info["period"] != 3
    ):
        raise RuntimeError("Rede incompatível.")

    artifacts = dict(ARTIFACTS)
    artifacts["code/beacon_executor.py"] = own_hash
    artifacts["beacon_executor_manifest.json"] = sha(manifest_path.read_bytes())
    for name in (
        "population_freeze.json",
        "planning/large_audit_design.json",
        "amendments/refinement01.json",
        "amendments/refinement01_review.json",
        "amendments/refinement02.json",
        "amendments/refinement02_review.json",
    ):
        artifacts[name] = sha((ROOT / name).read_bytes())

    commitment = {
        "artifact_sha256": artifacts,
        "adapter_sha256": adapter_hashes,
        "selection_sha256": settings["selection_sha256"],
        "chain_info": info,
        "chain_info_source": "Previously pinned audit_v1 plan",
        "N": 2048,
        "primary_n": 768,
        "delta": 0.05,
        "acceptance_threshold": 0.10,
        "public_timestamp_established": False,
    }
    commitment_path = ROOT / "pre_beacon_commitment.json"
    save_fixed(commitment_path, commitment)
    commitment_hash = sha(commitment_path.read_bytes())
    plan_path = ROOT / "beacon_plan.json"

    if args.stage == "reserve":
        if plan_path.exists():
            plan = json.loads(plan_path.read_text())
            if plan["commitment_sha256"] != commitment_hash:
                raise RuntimeError("Plano vinculado a outro compromisso.")
        else:
            latest = get_json(BASE + "/public/latest")
            print("Verificando assinatura da rodada observada...", flush=True)
            verify(latest, info)
            target = int(latest["round"]) + 100
            plan = {
                "commitment_sha256": commitment_hash,
                "observed_beacon": latest,
                "target_round": target,
                "scheduled_unix_seconds":
                    info["genesis_time"] + (target - 1) * info["period"],
                "chain_hash": CHAIN,
                "round_offset": 100,
            }
            save_fixed(plan_path, plan)

        from datetime import datetime, timezone
        print("COMPROMISSO E RODADA FUTURA FIXADOS")
        print("SHA256 do compromisso:", commitment_hash)
        print("SHA256 do plano:", sha(plan_path.read_bytes()))
        print("Rodada reservada:", plan["target_round"])
        print("Horário UTC:", datetime.fromtimestamp(
            plan["scheduled_unix_seconds"], timezone.utc
        ).isoformat())
        print("Nenhum Teacher consultado; sorteio ainda não realizado.")
        return

    plan = json.loads(plan_path.read_text())
    if (
        plan["commitment_sha256"] != commitment_hash
        or plan["chain_hash"] != CHAIN
        or plan["round_offset"] != 100
        or plan["target_round"] != int(plan["observed_beacon"]["round"]) + 100
    ):
        raise RuntimeError("Plano inconsistente.")
    verify(plan["observed_beacon"], info)

    beacon_path = ROOT / "beacon.json"
    beacon = (
        json.loads(beacon_path.read_text())
        if beacon_path.exists()
        else get_json(BASE + f"/public/{plan['target_round']}")
    )
    if beacon["round"] != plan["target_round"]:
        raise RuntimeError("Beacon de outra rodada.")
    print("Verificando assinatura da rodada reservada...", flush=True)
    verify(beacon, info)
    save_fixed(beacon_path, beacon)

    spec = importlib.util.spec_from_file_location(
        "fixed_large_sampler", ROOT / "code/sampler.py"
    )
    sampler = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(sampler)
    order = sampler.sample_order(
        settings["population_sha256"], beacon["randomness"], 2048
    )
    if sorted(order) != list(range(2048)):
        raise RuntimeError("Permutação inválida.")
    ids = [population_ids[i] for i in order]
    sample = {
        "commitment_sha256": commitment_hash,
        "beacon_plan_sha256": sha(plan_path.read_bytes()),
        "round": beacon["round"],
        "randomness": beacon["randomness"],
        "bls_verified": True,
        "ordered_ids": ids,
        "selected_ids": ids[:768],
    }
    save_fixed(ROOT / "sample.json", sample)
    print("BEACON VERIFICADO E AMOSTRA FIXADA")
    print("Rodada:", beacon["round"])
    print("SHA256 do sorteio:", sha((ROOT / "sample.json").read_bytes()))
    print("Relatos selecionados: 768")
    print("Nenhum Teacher consultado.")

if __name__ == "__main__":
    main()
