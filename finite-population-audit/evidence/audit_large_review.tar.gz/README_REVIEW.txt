Auditoria Teacher–Student: pacote de revisão independente.
População: 2048 relatos; amostra primária: 768.
Divergências primárias: 64; limite superior: 0.09765625.
Censo: 158 divergências em 2048 relatos.
Inclui dados, revisões, emendas, códigos, respostas brutas,
beacon, certificados, diagnósticos, tentativas e adapter.
Pesos base não incluídos: usar modelo e revisão das configurações.
Hashes demonstram integridade; não provam por si só proveniência
das respostas ou anterioridade pública dos compromissos.
Arquivo preparado para revisão; não publicado automaticamente.
