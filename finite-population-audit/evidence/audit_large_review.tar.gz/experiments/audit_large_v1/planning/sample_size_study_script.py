import hashlib
import json
from pathlib import Path

import scipy
from scipy.stats import hypergeom

OUT = Path("experiments/audit_large_v1/planning")
OUT.mkdir(parents=True, exist_ok=True)

N = 2048
DELTA = 0.05
THRESHOLD = 0.10
SIZES = [256, 384, 512, 768, 1024]
RATES = [0.03, 0.05, 0.07, 0.10]

def save_fixed(path, value):
    raw = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()
    if path.exists():
        if path.read_bytes() != raw:
            raise RuntimeError(f"Arquivo anterior diferente: {path}")
    else:
        with path.open("xb") as handle:
            handle.write(raw)
    return hashlib.sha256(raw).hexdigest()

plan = {
    "status": "sample_size_design_study; execution protocol not yet fixed",
    "planned_population_size": N,
    "delta": DELTA,
    "upper_bound_threshold": THRESHOLD,
    "candidate_sample_sizes": SIZES,
    "hypothetical_disagreement_rates": RATES,
    "rate_to_total": "nearest integer K; actual K/N reported",
    "method": "one-sided exact hypergeometric inversion",
    "student": "existing frozen Qwen2.5-1.5B adapter",
    "population_created_by_this_step": False,
    "teacher_calls": 0,
}
plan_hash = save_fixed(OUT / "sample_size_study_plan.json", plan)

def upper_total(k, n):
    low, high = k, N - n + k
    while low < high:
        middle = (low + high + 1) // 2
        if hypergeom.cdf(k, N, middle, n) > DELTA:
            low = middle
        else:
            high = middle - 1
    return low

# U <= 10% equivale a U_K <= floor(0.10*N) = 204.
maximum_acceptable_total = 204
results = []

for n in SIZES:
    # Maior número observado de divergências que permite atingir a meta.
    low, high = -1, n
    while low < high:
        middle = (low + high + 1) // 2
        if upper_total(middle, n) <= maximum_acceptable_total:
            low = middle
        else:
            high = middle - 1
    cutoff = low

    scenarios = []
    for rate in RATES:
        K = int(rate * N + 0.5)
        probability = (
            float(hypergeom.cdf(cutoff, N, K, n))
            if cutoff >= 0 else 0.0
        )
        scenarios.append({
            "hypothetical_rate": rate,
            "population_disagreements": K,
            "actual_rate": K / N,
            "probability_of_upper_bound_at_most_10_percent": probability,
        })

    results.append({
        "n": n,
        "query_fraction": n / N,
        "queries_avoided_vs_census": N - n,
        "maximum_sample_disagreements_for_target": cutoff,
        "upper_bound_at_cutoff": (
            upper_total(cutoff, n) / N if cutoff >= 0 else None
        ),
        "scenarios": scenarios,
    })

report = {
    "plan_sha256": plan_hash,
    "scipy_version": scipy.__version__,
    "results": results,
    "interpretation": (
        "Design probabilities conditional on hypothetical fixed tables. "
        "These scenarios do not predict the unknown new population rate. "
        "Candidate sizes are planning alternatives, not an adaptive "
        "stopping or repeated-testing procedure."
    ),
    "new_teacher_calls": 0,
    "new_training_steps": 0,
}
report_hash = save_fixed(OUT / "sample_size_study.json", report)

script_path = OUT / "sample_size_study_script.py"
script_raw = Path(__file__).read_bytes()
if script_path.exists():
    if script_path.read_bytes() != script_raw:
        raise RuntimeError("Script anterior diferente; preservado.")
else:
    with script_path.open("xb") as handle:
        handle.write(script_raw)

print("DIMENSIONAMENTO DA NOVA AUDITORIA")
print(f"N={N} | Meta: limite superior <=10% | Confiança: 95%")
print("Probabilidade de atingir a meta para cada taxa real hipotética:\n")
print("   n | Consultas/N | Máx. divergências |   ~3% |   ~5% |   ~7% |  ~10%")

for r in results:
    probabilities = [
        100 * s["probability_of_upper_bound_at_most_10_percent"]
        for s in r["scenarios"]
    ]
    print(
        f"{r['n']:4d} | {100*r['query_fraction']:10.2f}% | "
        f"{r['maximum_sample_disagreements_for_target']:17d} | "
        + " | ".join(f"{v:5.1f}%" for v in probabilities)
    )

print("\nTaxas efetivamente usadas nos cenários:")
for rate in RATES:
    K = int(rate * N + 0.5)
    print(f"Referência {rate:.0%}: K={K}; K/N={K/N:.4%}")

print("\nSHA256 do plano:", plan_hash)
print("SHA256 do estudo:", report_hash)
print("Arquivo:", OUT / "sample_size_study.json")
print("Nenhuma população criada, consulta ou treinamento realizado.")
