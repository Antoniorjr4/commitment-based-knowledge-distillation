import argparse
import hashlib
import json
import os
import platform
import resource
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path("experiments/audit_large_v1")
SETTINGS_HASH = "7eee96fd3fba6a6d740ce24a1be85775508ef938a15a8df6d889b425d819c738"
METHODS_HASH = "8f0dba8a0d5ab1dc85bd85cc630f947fcbf32c229f99053c872ad6fa32cbba06"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def checked(path, expected):
    raw = path.read_bytes()
    if sha(raw) != expected:
        raise RuntimeError(f"Hash diferente: {path}")
    return json.loads(raw)

def serialize(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()

def save_new(path, raw):
    with path.open("xb") as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())

def save_fixed(path, raw):
    if path.exists():
        if path.read_bytes() != raw:
            raise RuntimeError(f"Arquivo anterior diferente: {path}")
    else:
        save_new(path, raw)

def adapter_hashes(path):
    return {
        str(p.relative_to(path)): sha(p.read_bytes())
        for p in sorted(path.rglob("*")) if p.is_file()
    }

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--prepare", action="store_true")
    parser.add_argument("--run", action="store_true")
    args = parser.parse_args()
    if args.prepare == args.run:
        parser.error("Use somente --prepare ou --run.")

    settings = checked(ROOT / "execution_settings.json", SETTINGS_HASH)
    methods = checked(ROOT / "methods_manifest.json", METHODS_HASH)
    population = checked(
        ROOT / "population.json", settings["population_sha256"]
    )
    checked(
        ROOT / "population_freeze.json",
        settings["population_freeze_sha256"],
    )
    for name, expected in methods["code_sha256"].items():
        if sha((ROOT / "code" / name).read_bytes()) != expected:
            raise RuntimeError(f"Código de método alterado: {name}")

    adapter = Path(settings["adapter_path"])
    if adapter_hashes(adapter) != settings["adapter_sha256"]:
        raise RuntimeError("Adapter diferente do congelado.")

    code = Path(__file__).read_bytes()
    code_hash = sha(code)
    manifest = {
        "settings_sha256": SETTINGS_HASH,
        "methods_manifest_sha256": METHODS_HASH,
        "population_sha256": settings["population_sha256"],
        "executor_sha256": code_hash,
        "purpose": "Generate frozen Student responses; no Teacher calls",
    }

    if args.prepare:
        save_fixed(ROOT / "code/student_executor.py", code)
        save_fixed(
            ROOT / "student_executor_manifest.json", serialize(manifest)
        )
        print("EXECUTOR DO STUDENT FIXADO")
        print("SHA256 do executor:", code_hash)
        print("SHA256 do manifesto:", sha(serialize(manifest)))
        print("Nenhum modelo carregado; nenhuma inferência realizada.")
        return

    if (
        (ROOT / "code/student_executor.py").read_bytes() != code
        or json.loads(
            (ROOT / "student_executor_manifest.json").read_text()
        ) != manifest
    ):
        raise RuntimeError("Executor não corresponde ao preparado.")

    import psutil
    import torch
    import transformers
    import peft
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from peft import PeftModel

    torch.set_num_threads(settings["environment"]["threads"])
    torch.set_num_interop_threads(1)
    torch.manual_seed(settings["environment"]["seed"])

    environment = {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "torch": torch.__version__,
        "transformers": transformers.__version__,
        "peft": peft.__version__,
        "threads": torch.get_num_threads(),
        "device": "cpu",
        "dtype": "float32",
    }

    destination = ROOT / "student_responses"
    destination.mkdir(exist_ok=True)
    pending = []

    for row in population["rows"]:
        path = destination / f"{row['id']}.json"
        if not path.exists():
            pending.append(row)
            continue
        record = json.loads(path.read_text())
        if (
            record["settings_sha256"] != SETTINGS_HASH
            or record["executor_sha256"] != code_hash
            or record["population_sha256"] != settings["population_sha256"]
            or record["id"] != row["id"]
            or record["input_text"] != row["text"]
            or record["environment"] != environment
        ):
            raise RuntimeError(f"Resposta anterior incompatível: {path}")

    print(f"Respostas preservadas: {2048-len(pending)}/2048", flush=True)

    if pending:
        floor = settings["environment"]["memory_floor_mib"]

        def check_memory():
            available = psutil.virtual_memory().available / 1024**2
            if available < floor:
                raise SystemExit(
                    f"Parada operacional: RAM disponível {available:.0f} MiB. "
                    "Respostas concluídas preservadas."
                )

        check_memory()
        model_info = settings["student"]
        print("Carregando Student e adapter do cache local...", flush=True)
        tok = AutoTokenizer.from_pretrained(
            model_info["model"],
            revision=model_info["revision"],
            local_files_only=True,
        )
        base = AutoModelForCausalLM.from_pretrained(
            model_info["model"],
            revision=model_info["revision"],
            local_files_only=True,
            dtype=torch.float32,
            device_map="cpu",
            attn_implementation="eager",
        )
        model = PeftModel.from_pretrained(base, adapter)
        model.eval()

        logs = ROOT / "student_execution"
        logs.mkdir(exist_ok=True)
        save_fixed(logs / "environment.json", serialize(environment))
        packages = logs / "packages.txt"
        if not packages.exists():
            save_new(packages, subprocess.check_output(
                [sys.executable, "-m", "pip", "freeze"]
            ))

        for index, row in enumerate(pending, start=1):
            check_memory()
            prompt = tok.apply_chat_template(
                [{
                    "role": "user",
                    "content": settings["prompt_prefix"] + row["text"],
                }],
                tokenize=False,
                add_generation_prompt=True,
            )
            batch = tok(prompt, return_tensors="pt", truncation=False)
            input_tokens = int(batch["input_ids"].shape[1])
            maximum = getattr(model.config, "max_position_embeddings", None)
            new_tokens = settings["student_inference"]["max_new_tokens"]
            if maximum and input_tokens + new_tokens > maximum:
                raise RuntimeError(f"Entrada excede contexto: {row['id']}")

            started = time.perf_counter()
            with torch.inference_mode():
                output = model.generate(
                    **batch,
                    do_sample=False,
                    max_new_tokens=new_tokens,
                    use_cache=True,
                    pad_token_id=tok.eos_token_id,
                )
            elapsed = time.perf_counter() - started
            generated_ids = output[0, input_tokens:].tolist()
            answer = tok.decode(
                generated_ids, skip_special_tokens=True
            ).strip()

            record = {
                "settings_sha256": SETTINGS_HASH,
                "executor_sha256": code_hash,
                "population_sha256": settings["population_sha256"],
                "id": row["id"],
                "input_text": row["text"],
                "input_tokens": input_tokens,
                "generated_token_ids": generated_ids,
                "response": answer,
                "valid_exact_label": answer in ("ELETRICA", "MECANICA"),
                "generation_wall_seconds": elapsed,
                "environment": environment,
                "process_peak_rss_mib":
                    resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024,
            }
            save_new(
                destination / f"{row['id']}.json", serialize(record)
            )
            completed = 2048 - len(pending) + index
            if completed % 16 == 0 or completed == 2048:
                print(f"Student: {completed}/2048 concluídos", flush=True)

        del model, base
        if adapter_hashes(adapter) != settings["adapter_sha256"]:
            raise RuntimeError("Adapter mudou durante a execução.")

    # Conferir novamente e montar a tabela na ordem comprometida da população.
    table_rows = []
    file_hashes = {}
    for row in population["rows"]:
        path = destination / f"{row['id']}.json"
        record = json.loads(path.read_text())
        if (
            record["settings_sha256"] != SETTINGS_HASH
            or record["executor_sha256"] != code_hash
            or record["population_sha256"] != settings["population_sha256"]
            or record["id"] != row["id"]
            or record["input_text"] != row["text"]
            or record["environment"] != environment
        ):
            raise RuntimeError(f"Registro inconsistente: {row['id']}")
        file_hashes[path.name] = sha(path.read_bytes())
        table_rows.append({
            "id": row["id"],
            "response": record["response"],
        })

    table = {
        "settings_sha256": SETTINGS_HASH,
        "population_sha256": settings["population_sha256"],
        "executor_sha256": code_hash,
        "N": len(table_rows),
        "rows": table_rows,
        "response_file_sha256": file_hashes,
    }
    table_raw = serialize(table)
    save_fixed(ROOT / "student_table.json", table_raw)
    print("\nSTUDENT CONCLUÍDO: 2.048 respostas fixadas", flush=True)
    print("SHA256 da tabela:", sha(table_raw), flush=True)
    print("Nenhum Teacher consultado; nenhuma amostra sorteada.", flush=True)

if __name__ == "__main__":
    main()
