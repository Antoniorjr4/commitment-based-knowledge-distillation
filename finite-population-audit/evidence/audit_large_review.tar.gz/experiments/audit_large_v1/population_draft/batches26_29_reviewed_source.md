ID	Texto A	Texto B	Reparo principal
E401	A bobina da válvula de retenção pilotada eletricamente está aberta.	O teste confirmou interrupção no enrolamento que aciona o piloto elétrico da válvula de retenção.	Substituir a bobina
E402	O cabo de alimentação da mesa magnética apresenta curto entre condutores.	O ensaio localizou curto-circuito entre os fios que alimentam a mesa eletromagnética.	Substituir ou reparar o cabo
E403	O transformador de isolamento apresenta ligação elétrica indevida entre primário e secundário por erro de montagem externa.	A conferência identificou uma ponte externa não prevista unindo os circuitos primário e secundário do transformador de isolamento.	Remover a ligação indevida e conferir o circuito
E404	O aquecedor apresenta terminal energizado sem a capa isolante especificada.	A montagem deixou exposta a conexão elétrica do aquecedor por ausência da cobertura isolante prevista.	Instalar a proteção correta
E405	O circuito de emergência apresenta contato normalmente fechado ligado em paralelo indevidamente a outro contato.	A conferência identificou associação elétrica em paralelo não prevista entre contatos da malha de emergência.	Recompor conforme projeto
E406	O conector de alimentação apresenta pinos ligados em sequência diferente da especificada.	A pinagem instalada no conector de potência não corresponde ao esquema aprovado.	Corrigir a pinagem
E407	O contato de aterramento da tomada apresenta pressão insuficiente e resistência elevada.	O ensaio confirmou conexão de proteção resistiva devido à perda de pressão do contato de terra da tomada.	Substituir a tomada
E408	A chave de transferência apresenta terminal de comando com ligação interna interrompida.	O teste localizou circuito aberto na conexão interna ao borne de comando da chave de transferência.	Recuperar ou substituir o conjunto
E409	O conversor apresenta resistor de limitação da alimentação auxiliar com valor incorreto.	A conferência identificou resistor com valor diferente do especificado na entrada da fonte auxiliar do conversor.	Instalar o componente correto
E410	A placa de potência apresenta isolador de montagem ausente, permitindo contato elétrico com o suporte.	A falta do espaçador isolante previsto conecta indevidamente a placa de potência à estrutura metálica.	Corrigir a montagem e avaliar danos
E411	O circuito de sincronismo apresenta cabo de referência de fase eletricamente aberto.	A referência de sincronismo foi interrompida por ruptura de um fio do cabo de fase do circuito.	Reparar ou substituir o cabo
E412	O relé de pré-carga apresenta contato soldado, mantendo o circuito fechado sem comando.	O circuito de pré-carga permanece conectado porque o contato do relé está unido por soldagem.	Substituir o relé
E413	O sensor de condutividade apresenta circuito eletrônico de excitação danificado.	O teste confirmou falha na eletrônica que gera a excitação do sensor de condutividade.	Reparar ou substituir o conjunto
E414	O cabo do sensor de pressão apresenta conexão de sinal trocada com o retorno.	A conferência identificou inversão dos fios de saída e retorno no sensor de pressão.	Corrigir a ligação
E415	O módulo de entrada de temperatura apresenta canal com curto interno para a referência elétrica.	O ensaio confirmou curto entre um canal de temperatura e o comum interno do módulo.	Reparar ou substituir o módulo
E416	O sinalizador de painel apresenta terminal de alimentação desprendido internamente.	A ausência de continuidade foi localizada na conexão interna do borne de alimentação do sinalizador.	Substituir o sinalizador


Lote 26 — mecânica
ID	Texto A	Texto B	Reparo principal
M401	O eixo apresenta chaveta montada com altura excessiva, impedindo o assentamento do cubo.	A dimensão incorreta da chaveta mantém o cubo sem o ajuste previsto no eixo.	Instalar a chaveta correta
M402	A transmissão apresenta correia apoiada no fundo do canal por incompatibilidade de perfil.	A inspeção confirmou que o perfil incorreto faz a correia tocar o fundo do sulco da polia.	Instalar componentes compatíveis
M403	O rolamento apresenta arruela de trava montada sem engate no rasgo do eixo.	O elemento que bloqueia a porca do rolamento não está encaixado na ranhura prevista do eixo.	Corrigir a montagem
M404	O acoplamento apresenta cubos em contato entre si por espaçamento axial insuficiente.	A montagem deixou folga pequena demais entre os cubos, provocando interferência mecânica no acoplamento.	Corrigir o espaçamento e avaliar danos
M405	A bomba apresenta tubulação conectada com desalinhamento que força sua carcaça.	A montagem da linha impõe esforço ao corpo da bomba devido ao desalinhamento da conexão.	Corrigir a tubulação e verificar o alinhamento
M406	A válvula apresenta sede com resíduo sólido preso na superfície de fechamento.	A inspeção confirmou partícula retida entre o obturador e a sede da válvula.	Limpar e avaliar as superfícies
M407	A união de tubulação apresenta junta instalada em duplicidade, contrariando a montagem especificada.	A conferência identificou duas juntas sobrepostas onde o projeto prevê apenas uma.	Corrigir a montagem
M408	O suporte da tubulação apresenta guia lateral montada com folga insuficiente.	A regulagem do apoio restringe o movimento previsto porque a folga lateral está abaixo do especificado.	Corrigir o ajuste
M409	O cilindro hidráulico apresenta pistão montado com orientação contrária à especificada.	A conferência interna confirmou inversão da posição de montagem do pistão hidráulico.	Corrigir a montagem e avaliar componentes
M410	A válvula pneumática apresenta silenciador com rosca fraturada na conexão de escape.	A inspeção confirmou ruptura do terminal roscado que fixa o silenciador ao escape da válvula.	Substituir e verificar a conexão
M411	O conjunto hidráulico apresenta abraçadeira de tubo sem o inserto de apoio especificado.	A fixação da linha hidráulica foi montada sem a peça prevista entre o tubo e a abraçadeira.	Instalar o componente e avaliar o tubo
M412	A bomba de lubrificação apresenta engrenagem de acionamento solta no eixo.	A fixação da engrenagem que movimenta a bomba de lubrificante perdeu retenção no eixo.	Recuperar a fixação
M413	O transportador apresenta rolete instalado em suporte de altura incompatível.	A montagem deixou o rolete fora da linha prevista porque seu suporte tem altura incorreta.	Instalar ou ajustar o suporte correto
M414	O carro apresenta roda com pista de rodagem lascada.	A inspeção identificou desprendimento localizado de material na superfície de rodagem da roda do carro.	Substituir e investigar a causa
M415	A proteção apresenta fecho montado sem o parafuso de retenção especificado.	A montagem do fecho da proteção está incompleta por ausência de um fixador previsto.	Instalar o fixador correto
M416	O mecanismo apresenta cabo de aço prensado em terminal incompatível com seu diâmetro.	A conferência identificou terminal de prensagem inadequado para a dimensão do cabo de aço.	Substituir o conjunto conforme especificação


Lote 27 — elétrica
ID	Texto A	Texto B	Reparo principal
E417	O enrolamento do motor apresenta terminal interno ligado à fase incorreta em relação ao esquema.	A conferência confirmou conexão interna de fase diferente da prevista no projeto do motor.	Corrigir a ligação
E418	A bobina da válvula direcional apresenta curto entre seu terminal e o núcleo metálico.	O ensaio confirmou contato elétrico indevido entre um terminal da bobina da válvula direcional e seu núcleo.	Substituir a bobina ou conjunto
E419	O transformador apresenta cabo secundário com seção inferior à especificada e aquecimento confirmado.	A ligação secundária aquece porque o condutor instalado tem seção menor que a prevista no projeto.	Instalar o cabo especificado
E420	O aquecedor apresenta ligação de proteção desconectada de sua bainha metálica.	O teste confirmou ausência da conexão de aterramento prevista no invólucro do aquecedor.	Restabelecer a ligação
E421	O circuito de intertravamento apresenta condutor conectado ao contato errado da chave.	A conferência identificou terminação incorreta no bloco de contatos da chave de intertravamento.	Corrigir a ligação
E422	O terminal de alimentação do painel apresenta contato entre fases por filamentos soltos.	A terminação defeituosa deixou fios do condutor encostarem em um borne de outra fase.	Refazer a terminação e avaliar danos
E423	O relé de proteção apresenta conector de teste com pino de sinal rompido.	O circuito de teste do relé está interrompido por fratura de um terminal do conector.	Substituir o conector ou conjunto
E424	A barra de neutro está conectada à carcaça em ponto onde o projeto exige separação elétrica.	A inspeção identificou união indevida entre neutro e estrutura metálica em trecho que deveria permanecer separado.	Recompor conforme projeto
E425	O filtro do conversor apresenta ligação de saída conectada ao terminal de entrada por erro de montagem.	A conferência identificou conexão incorreta entre os bornes de entrada e saída do filtro do conversor.	Corrigir a ligação
E426	O driver apresenta conector com contato de saída rompido.	O comando do driver não chega ao módulo porque um terminal de saída do conector está fraturado.	Substituir o conector ou placa
E427	O banco de capacitores apresenta fusível de um ramo aberto, com causa já corrigida.	Após corrigir a causa da atuação, um ramo do banco permanece desligado por fusível interrompido.	Substituir o fusível
E428	O circuito de medição de corrente apresenta conector instalado em posição que troca sinal e alimentação.	A montagem incorreta do conector inverte as ligações de alimentação e saída do circuito de corrente.	Corrigir a montagem e avaliar danos
E429	O sensor de inclinação apresenta saída eletrônica danificada, com alimentação normal.	O ensaio confirmou defeito no estágio de saída do sensor de inclinação, apesar da alimentação adequada.	Substituir ou reparar o sensor
E430	O módulo de pesagem apresenta ligação de referência da célula de carga interrompida no borne.	A ausência da referência de medição foi localizada em um terminal desconectado da célula de carga.	Restabelecer a conexão
E431	O contato da chave de seleção local-remoto não abre na posição especificada.	O teste confirmou continuidade indevida no contato da chave local-remoto quando deveria estar aberto.	Substituir o bloco de contato
E432	O cabo do instrumento apresenta entrada de umidade pelo prensa-cabo e fuga entre condutores.	A falha de vedação da entrada do cabo permitiu umidade com perda de isolamento na ligação do instrumento.	Recuperar a entrada e substituir componentes comprometidos


Lote 27 — mecânica
ID	Texto A	Texto B	Reparo principal
M417	O rolamento apresenta montagem com esforço aplicado ao anel incorreto e dano confirmado nas pistas.	A inspeção identificou marcas nas pistas decorrentes da transmissão indevida do esforço de montagem pelos corpos rolantes.	Substituir e corrigir o método de montagem
M418	A engrenagem apresenta fixação por chaveta com folga lateral acima da tolerância.	A medição confirmou ajuste lateral excessivo entre a chaveta e o rasgo da engrenagem.	Recuperar o ajuste ou substituir componentes
M419	O eixo apresenta porca de retenção montada com rosca cruzada.	A união roscada de retenção do eixo foi danificada por montagem desalinhada da porca.	Recuperar ou substituir componentes
M420	O acoplamento apresenta elemento flexível incompatível com a dimensão especificada.	A conferência identificou peça flexível de tamanho incorreto no conjunto do acoplamento.	Instalar o componente correto
M421	A bomba apresenta impulsor montado em posição axial incorreta no eixo.	A verificação dimensional confirmou posicionamento axial do impulsor diferente do especificado.	Corrigir a montagem
M422	A válvula apresenta haste sem o elemento de retenção previsto na montagem.	A montagem da haste está incompleta porque falta seu componente de travamento especificado.	Instalar e verificar o conjunto
M423	A tubulação apresenta junta de material incompatível com a especificação do serviço.	A conferência identificou vedação fabricada em material diferente do aprovado para a linha.	Instalar a junta especificada
M424	O suporte da tubulação apresenta ancoragem com engajamento de rosca abaixo do mínimo previsto.	A fixação do apoio utiliza comprimento roscado insuficiente em relação ao projeto.	Corrigir a ancoragem
M425	O cilindro pneumático apresenta amortecedor de fim de curso montado com peça de dimensão incorreta.	A conferência identificou componente de amortecimento incompatível com a montagem especificada do cilindro.	Instalar a peça correta
M426	A válvula hidráulica apresenta pino de posicionamento ausente entre corpo e placa.	A montagem da interface hidráulica está sem o elemento previsto para posicionar a válvula sobre a placa.	Corrigir a montagem
M427	O reservatório hidráulico apresenta tubo interno de retorno desprendido.	A inspeção confirmou perda de fixação da tubulação de retorno no interior do tanque hidráulico.	Recuperar a fixação
M428	A linha de graxa apresenta conexão montada com diâmetro interno menor que o especificado.	A passagem de lubrificante foi restringida por um conector de furo inferior ao previsto.	Instalar a conexão correta
M429	O transportador apresenta tambor com anel de fixação do eixo solto.	A união do eixo ao tambor perdeu aperto no conjunto de fixação anular.	Restabelecer o ajuste e avaliar danos
M430	O carro apresenta guia lateral montada com folga abaixo da especificada e interferência no movimento.	O ajuste excessivamente fechado da guia restringe o deslocamento do carro.	Corrigir a regulagem
M431	A proteção apresenta tela presa com fixadores incompatíveis com a especificação.	A conferência identificou elementos de fixação incorretos na montagem da tela da proteção.	Instalar os fixadores corretos
M432	O mecanismo apresenta eixo de articulação com corrosão e travamento confirmado.	A corrosão bloqueou o movimento do eixo na articulação do mecanismo.	Recuperar ou substituir componentes


Lote 28 — elétrica
ID	Texto A	Texto B	Reparo principal
E433	O motor apresenta cabo do sensor térmico com curto para um terminal de potência.	O ensaio localizou contato elétrico indevido entre a ligação do sensor térmico e a alimentação de potência do motor.	Recuperar as ligações e avaliar danos
E434	A bobina do eletroímã apresenta condutor de alimentação rompido na saída do enrolamento.	A continuidade da bobina foi perdida na ruptura do fio junto à saída do enrolamento do eletroímã.	Recuperar ou substituir a bobina
E435	O transformador apresenta isolação superficial do terminal contaminada e com corrente de fuga confirmada.	Os resíduos condutivos no isolador do terminal do transformador permitem fuga pela superfície.	Limpar ou substituir conforme avaliação
E436	O aquecedor apresenta elemento resistivo com potência incompatível por associação incorreta dos módulos.	A ligação dos módulos de aquecimento contraria o esquema e resulta em potência diferente da especificada.	Corrigir a associação
E437	O circuito de comando apresenta borne com identificação trocada e ligação executada no ponto incorreto.	A identificação incorreta dos terminais levou à conexão do comando em borne diferente do previsto.	Corrigir identificação e ligação
E438	O contato do relé de bloqueio apresenta resistência excessiva quando fechado.	O ensaio confirmou contato resistivo acima da especificação na saída acionada do relé de bloqueio.	Reparar ou substituir o relé
E439	A ligação de proteção da esteira porta-cabos metálica está interrompida entre dois segmentos.	O teste confirmou falta de continuidade de aterramento na união entre partes da esteira metálica de cabos.	Recompor a ligação
E440	O terminal de alimentação contínua apresenta ponte montada entre positivo e retorno por erro de instalação.	A conferência identificou uma interligação indevida que curto-circuita os polos da alimentação contínua.	Remover a ponte e avaliar danos
E441	O conversor apresenta cabo de habilitação conectado à entrada de função diferente da especificada.	A conferência confirmou terminação do comando de habilitação em borne incorreto do conversor.	Corrigir a ligação
E442	O resistor de descarga apresenta terminação frouxa e aquecimento na conexão.	A inspeção localizou aquecimento na ligação mal apertada do resistor de descarga.	Refazer a conexão e avaliar danos
E443	A placa de controle apresenta conector montado com um pino dobrado e sem continuidade.	O sinal está interrompido porque um terminal foi deformado ao encaixar o conector da placa de controle.	Substituir ou recuperar o conector
E444	O sensor de corrente apresenta ligação de alimentação com polaridade invertida.	Os fios positivo e negativo estão trocados no circuito que alimenta o transdutor de corrente.	Corrigir a ligação e avaliar danos
E445	O sensor de umidade apresenta eletrônica de saída danificada, com alimentação adequada.	O ensaio confirmou falha no estágio de saída do sensor de umidade, apesar da alimentação correta.	Substituir ou reparar o sensor
E446	O circuito do transmissor apresenta cabo conectado ao canal errado do módulo de entrada.	A conferência identificou sinal do transmissor ligado a uma entrada diferente da prevista no módulo.	Corrigir a ligação
E447	O módulo remoto apresenta conector de alimentação com contato carbonizado.	A inspeção localizou dano por carbonização no terminal que alimenta o módulo remoto.	Substituir os componentes comprometidos
E448	O circuito eletrônico do contador de pulsos apresenta entrada com curto interno.	O ensaio confirmou curto no estágio eletrônico de entrada do contador de pulsos.	Reparar ou substituir o contador


Lote 28 — mecânica
ID	Texto A	Texto B	Reparo principal
M433	O rolamento apresenta montagem invertida em relação à orientação especificada para o conjunto.	A conferência confirmou posição de instalação do rolamento contrária ao desenho de montagem.	Corrigir a montagem e avaliar danos
M434	A polia apresenta balanceamento fora da tolerância por perda de um contrapeso de fixação.	A ausência do peso de correção provocou desequilíbrio confirmado na polia.	Recompor e verificar o balanceamento
M435	O acoplamento apresenta fixação do elemento flexível com aperto abaixo do especificado.	A inspeção confirmou torque insuficiente nos fixadores do elemento flexível do acoplamento.	Corrigir o aperto e avaliar danos
M436	A corrente apresenta placa de elo deformada lateralmente além do limite permitido.	A inspeção confirmou empenamento excessivo de uma chapa lateral da corrente.	Substituir conforme especificação
M437	A bomba apresenta furo de posicionamento da tampa danificado, impedindo a montagem correta do pino.	O alojamento do pino-guia da tampa da bomba está comprometido e não permite o posicionamento especificado.	Recuperar ou substituir componentes
M438	A válvula apresenta junta da tampa montada com dobra que compromete a vedação.	A inspeção confirmou vinco de montagem na junta da tampa da válvula, com perda de assentamento.	Substituir e corrigir a montagem
M439	A tubulação apresenta flange com face riscada acima do limite permitido para vedação.	A inspeção confirmou sulcos excessivos na superfície de assentamento da junta do flange.	Recuperar ou substituir conforme avaliação
M440	O suporte da tubulação apresenta calço instalado fora da posição especificada.	A montagem deslocou a peça de ajuste do apoio da tubulação para uma posição incorreta.	Corrigir o posicionamento
M441	O cilindro hidráulico apresenta pistão montado sem o anel de apoio da vedação previsto.	A montagem da vedação do pistão está sem o componente de apoio especificado no cilindro hidráulico.	Instalar a peça correta e avaliar a vedação
M442	A conexão pneumática apresenta tubo cortado em ângulo incompatível com a montagem especificada.	O corte inclinado da extremidade do tubo impede seu assentamento correto na conexão de ar.	Refazer a extremidade e verificar a conexão
M443	A válvula hidráulica apresenta obturador com partícula incrustada na superfície vedante.	A inspeção identificou resíduo preso à face de vedação do obturador hidráulico.	Limpar ou substituir conforme avaliação
M444	O reservatório de lubrificante apresenta tampa de abastecimento com rosca danificada.	A tampa de enchimento do reservatório não pode ser fixada corretamente por dano em sua rosca.	Substituir ou recuperar o conjunto
M445	O transportador apresenta raspador com lâmina instalada no sentido contrário ao especificado.	A conferência confirmou orientação invertida da lâmina do raspador da correia.	Corrigir a montagem
M446	O carro apresenta roda com fixação axial sem a arruela especificada.	A montagem da roda está sem a arruela prevista no conjunto de retenção axial.	Instalar e conferir o ajuste
M447	A proteção apresenta trilho deslizante com fixação frouxa.	A guia da proteção se movimenta indevidamente porque seus fixadores perderam aperto.	Restabelecer a fixação
M448	O mecanismo apresenta alavanca montada com bucha de comprimento incorreto.	A conferência dimensional identificou bucha incompatível com a largura de montagem da alavanca.	Instalar a bucha correta


Lote 29 — elétrica
ID	Texto A	Texto B	Reparo principal
E449	O motor apresenta terminal de fase com condutor instalado sem o comprimento de inserção especificado.	A ligação do cabo de fase ao motor tem engajamento insuficiente do condutor no terminal.	Refazer a terminação
E450	A bobina da válvula de bloqueio apresenta resistência infinita por ruptura do enrolamento.	O teste confirmou circuito aberto na bobina que aciona a válvula de bloqueio.	Substituir a bobina
E451	O transformador apresenta ligação secundária com condutores de polaridade de referência trocados.	A conferência confirmou inversão da polaridade prevista nos terminais secundários do transformador.	Corrigir a ligação
E452	O aquecedor apresenta circuito de potência interrompido no contato do relé de comando.	O ensaio localizou contato aberto defeituoso no relé que alimenta a resistência de aquecimento.	Substituir o relé ou conjunto
E453	A chave de seleção apresenta contato normalmente fechado conectado onde o projeto prevê normalmente aberto.	A ligação instalada utiliza a função de contato oposta à especificada no esquema da chave seletora.	Corrigir a ligação
E454	A tomada industrial apresenta condutor de fase ligado ao contato de proteção por erro de montagem.	A conferência identificou alimentação de fase conectada indevidamente ao terminal de terra da tomada.	Corrigir a ligação e avaliar danos
E455	O circuito do relé apresenta tensão de bobina incompatível com a especificação do componente instalado.	O relé montado possui tensão nominal de bobina diferente da alimentação prevista no circuito.	Instalar o componente correto
E456	O terminal da barra de proteção apresenta superfície de contato coberta por material isolante indevido.	A conexão de aterramento está comprometida por uma camada isolante entre terminal e barra de proteção.	Recompor o contato conforme especificação
E457	O módulo de potência apresenta cabo de disparo conectado ao canal incorreto.	A conferência confirmou sinal de disparo ligado a uma entrada diferente da prevista no módulo de potência.	Corrigir a ligação e avaliar danos
E458	O circuito de alimentação auxiliar apresenta diodo montado em sentido contrário ao especificado.	A inspeção confirmou inversão do diodo na placa da fonte auxiliar.	Corrigir a montagem e avaliar danos
E459	O resistor de limitação do circuito de controle apresenta valor acima da especificação por degradação.	A medição confirmou aumento indevido da resistência do componente limitador do circuito de controle.	Substituir o resistor
E460	O conversor apresenta conector de medição com trava quebrada e contato intermitente.	A perda de retenção do conector de medição provoca falhas de contato no conversor.	Substituir o conector
E461	O transmissor apresenta circuito de saída conectado ao terminal de alimentação do módulo receptor.	A conferência identificou sinal do transmissor ligado indevidamente a um borne de alimentação da entrada receptora.	Corrigir a ligação e avaliar danos
E462	O sensor de presença apresenta circuito de entrada de alimentação eletricamente aberto.	O diagnóstico confirmou interrupção interna na alimentação do sensor de presença.	Substituir ou reparar o sensor
E463	A chave de comando apresenta contato com isolação comprometida para seu suporte metálico.	O ensaio confirmou fuga elétrica do contato da chave para sua estrutura de montagem.	Substituir o conjunto
E464	O módulo de aquisição apresenta cabo de referência conectado a um terminal incorreto.	A conferência identificou ligação do comum de medição em ponto diferente do previsto no módulo.	Corrigir a ligação


Lote 29 — mecânica
ID	Texto A	Texto B	Reparo principal
M449	O eixo apresenta superfície cônica de montagem com marcas de impacto acima da tolerância.	A inspeção confirmou deformações por golpes na região cônica de ajuste do eixo.	Recuperar ou substituir conforme avaliação
M450	A engrenagem apresenta face lateral em contato com a carcaça por espaçador ausente.	A falta da peça de espaçamento provocou interferência entre a engrenagem e a caixa da transmissão.	Corrigir a montagem e avaliar danos
M451	O acoplamento apresenta elemento flexível deteriorado por temperatura acima da condição especificada.	A inspeção confirmou degradação térmica da peça flexível do acoplamento.	Substituir e corrigir a causa
M452	A transmissão apresenta correia com comprimento incompatível com a faixa de ajuste do tensionador.	O tensionamento previsto não pode ser obtido porque o comprimento da correia instalada é incorreto.	Instalar a correia especificada
M453	A bomba apresenta selo mecânico com anel vedante secundário rompido.	A inspeção confirmou ruptura da vedação secundária do conjunto do selo mecânico da bomba.	Substituir e verificar a montagem
M454	A válvula apresenta sede com dimensão incompatível com o alojamento do corpo.	A peça de assentamento instalada não corresponde ao ajuste dimensional previsto na válvula.	Instalar a sede correta
M455	A tubulação apresenta suporte instalado fora da posição prevista no projeto.	A conferência identificou apoio da linha em localização diferente da especificada no desenho de montagem.	Corrigir o posicionamento e avaliar esforços
M456	O flange apresenta porcas de classe mecânica inferior à especificada.	A conferência confirmou elementos roscados de resistência inadequada na união flangeada.	Instalar os componentes corretos
M457	O cilindro hidráulico apresenta fixação do olhal da haste com contraporca frouxa.	O olhal da haste perdeu o bloqueio de posição porque sua contraporca afrouxou.	Restabelecer a fixação e verificar o conjunto
M458	A válvula pneumática apresenta conexão de escape instalada com elemento vedante bloqueando a passagem.	O excesso de material de vedação obstrui o canal de exaustão na conexão da válvula pneumática.	Refazer a união e remover resíduos
M459	A mangueira hidráulica apresenta comprimento insuficiente, ficando tracionada no curso normal do mecanismo.	O movimento previsto tensiona a mangueira porque o trecho instalado é curto demais.	Instalar a mangueira especificada
M460	O circuito de lubrificação apresenta tubo com extremidade deformada e seção de passagem reduzida.	A inspeção confirmou amassamento na ponta do tubo que restringe o fluxo de lubrificante.	Substituir ou recuperar o trecho
M461	O transportador apresenta suporte do tambor montado com calço de espessura incorreta.	A conferência identificou peça de ajuste incompatível com a altura prevista do suporte do tambor.	Corrigir a montagem e verificar o alinhamento
M462	O carro apresenta batente com elemento elastomérico montado fora de posição.	A peça amortecedora do batente está deslocada do assentamento previsto no carro.	Corrigir a montagem e avaliar o elemento
M463	A proteção apresenta fecho com curso de engate insuficiente por ajuste incorreto.	A regulagem do fecho não permite o engajamento mínimo especificado para reter a proteção.	Corrigir o ajuste
M464	O mecanismo apresenta biela montada com distância entre centros diferente da especificada.	A conferência dimensional confirmou comprimento funcional incorreto da biela instalada.	Instalar ou ajustar conforme projeto

