ID	Texto A	Texto B	Reparo principal
E465	O cabo de alimentação do motor apresenta terminais de duas fases encostados por montagem incorreta.	A disposição inadequada das terminações provoca contato elétrico entre duas fases na caixa do motor.	Corrigir a montagem e avaliar danos
E466	A bobina do acoplamento eletromagnético apresenta fuga elétrica para a carcaça.	O ensaio confirmou perda de isolamento entre o enrolamento do acoplamento eletromagnético e sua estrutura metálica.	Substituir ou recuperar a bobina
E467	O transformador apresenta conexão do secundário à carga com terminal de crimpagem incompatível com a seção do cabo.	A terminação do cabo secundário foi montada com terminal inadequado para a dimensão do condutor.	Refazer a terminação
E468	O aquecedor apresenta borne cerâmico trincado e perda de isolamento confirmada.	O ensaio localizou falha de isolação no bloco cerâmico fissurado dos terminais do aquecedor.	Substituir o borne e avaliar danos
E469	O circuito de comando apresenta relé instalado com disposição de pinos incompatível com o soquete.	O relé montado possui pinagem diferente da prevista para a base de conexão do circuito.	Instalar o componente correto
E470	A chave seccionadora apresenta contato móvel desalinhado e ausência de continuidade na posição fechada.	O desalinhamento do contato móvel impede a conexão elétrica de um polo da seccionadora fechada.	Recuperar ou substituir conforme especificação
E471	O cabo de proteção apresenta emenda com continuidade interrompida por ruptura da união.	O teste confirmou circuito aberto na emenda do condutor de aterramento.	Refazer a ligação conforme especificação
E472	O terminal de alimentação do painel apresenta conexão montada sobre superfície oxidada e resistência excessiva.	O ensaio confirmou contato resistivo elevado na união elétrica oxidada de entrada do painel.	Recuperar a conexão
E473	A placa do conversor apresenta resistor de polarização eletricamente aberto.	O ensaio confirmou interrupção no resistor que estabelece a polarização de um estágio da placa do conversor.	Substituir o componente ou placa
E474	O módulo de potência apresenta conexão de proteção do dissipador interrompida.	O teste confirmou falta de continuidade na ligação de aterramento do dissipador do módulo de potência.	Restabelecer a conexão
E475	O circuito de potência apresenta capacitor instalado com tensão nominal inferior à especificada.	A conferência identificou capacitor com classe de tensão inadequada para o projeto do circuito de potência.	Instalar o componente correto
E476	O cabo de comando do retificador apresenta blindagem desconectada do terminal previsto.	A ligação especificada da blindagem do cabo de comando do retificador está interrompida no conector.	Restabelecer conforme projeto
E477	O sensor de posição apresenta terminal de saída com solda rompida internamente.	A continuidade do sinal foi perdida na união soldada do terminal de saída do sensor de posição.	Reparar ou substituir o sensor
E478	O cabo do instrumento apresenta conector com pinagem incompatível com a documentação de ligação.	A distribuição dos condutores nos pinos do conector do instrumento não corresponde ao esquema aprovado.	Corrigir a pinagem
E479	O módulo de entrada apresenta alimentação ligada ao borne de referência de sinal por erro de montagem.	A conferência identificou condutor de alimentação conectado indevidamente ao comum de medição do módulo.	Corrigir a ligação e avaliar danos
E480	O sinalizador sonoro apresenta ligação interna ao terminal de alimentação interrompida.	O teste localizou circuito aberto na conexão entre o borne e o circuito interno do sinalizador sonoro.	Reparar ou substituir o sinalizador


Lote 30 — mecânica
ID	Texto A	Texto B	Reparo principal
M465	O eixo apresenta bucha de ajuste montada com parede de espessura incompatível.	A conferência dimensional identificou bucha incorreta no ajuste de montagem do eixo.	Instalar a bucha especificada
M466	A engrenagem apresenta furo de montagem com diâmetro acima da tolerância.	A medição confirmou alojamento da engrenagem excessivamente largo para o ajuste previsto no eixo.	Recuperar ou substituir conforme avaliação
M467	O acoplamento apresenta flange montado com parafusos em quantidade inferior à especificada.	A união flangeada do acoplamento está sem parte dos fixadores previstos no projeto.	Completar a montagem e avaliar a união
M468	A transmissão apresenta tensionador montado com curso disponível insuficiente por posicionamento incorreto.	A posição de instalação do tensionador impede alcançar a faixa de regulagem especificada.	Corrigir a montagem
M469	A bomba apresenta tampa com espessura de junta diferente da especificada, alterando a folga interna.	A junta incorreta da tampa modificou o ajuste interno previsto para a bomba.	Instalar a junta correta e conferir folgas
M470	A válvula apresenta obturador com diâmetro incompatível com a sede instalada.	A conferência dimensional confirmou incompatibilidade entre o elemento de fechamento e a sede da válvula.	Instalar os componentes corretos
M471	A tubulação apresenta conexão montada com roscas de padrões incompatíveis.	A união utiliza componentes roscados que não correspondem ao mesmo padrão especificado.	Substituir pelos componentes corretos
M472	O suporte da tubulação apresenta superfície de apoio danificada por corrosão além do limite admissível.	A inspeção confirmou perda excessiva de material na região de sustentação do apoio da linha.	Recuperar ou substituir conforme avaliação
M473	O cilindro hidráulico apresenta anel-guia da haste montado com folga incorreta por dimensão inadequada.	A conferência confirmou bucha de guiamento da haste incompatível com o ajuste especificado.	Instalar a guia correta
M474	A válvula pneumática apresenta tampa montada com aperto desigual e vazamento na junta.	A distribuição incorreta do aperto da tampa compromete a vedação externa da válvula de ar.	Corrigir a montagem e avaliar a junta
M475	A mangueira hidráulica apresenta reforço exposto por contato contínuo com uma aresta.	O atrito contra uma borda removeu a cobertura e expôs a camada estrutural da mangueira de óleo.	Substituir e corrigir o percurso
M476	O circuito de graxa apresenta conexão de saída montada sem a vedação especificada.	A união de saída da linha de graxa está sem o elemento vedante previsto no projeto.	Instalar a vedação correta
M477	O transportador apresenta rolete montado com sentido de instalação contrário ao desenho do conjunto.	A conferência confirmou orientação incorreta do rolete em relação à montagem especificada.	Corrigir a instalação
M478	O carro apresenta roda com diâmetro incompatível com as demais rodas do conjunto.	A medição confirmou roda instalada com dimensão diferente da especificada para o conjunto do carro.	Instalar a roda correta
M479	A proteção apresenta batente com fixador de comprimento insuficiente para retenção.	O parafuso instalado no batente da proteção é curto demais para o engajamento previsto.	Instalar o fixador correto
M480	O mecanismo apresenta biela com olhal ovalizado além da tolerância.	A medição confirmou desgaste excessivo no furo de articulação da biela.	Recuperar ou substituir conforme avaliação


Lote 31 — elétrica
ID	Texto A	Texto B	Reparo principal
E481	O motor apresenta terminal de ligação com aperto excessivo e ruptura confirmada do condutor.	A aplicação de torque acima do previsto danificou o fio e interrompeu a conexão no terminal do motor.	Refazer a terminação e avaliar o borne
E482	A bobina do solenóide apresenta cabo externo ligado em tensão incompatível com sua especificação.	A alimentação instalada aplica à bobina do solenóide uma tensão diferente da nominal permitida.	Corrigir a alimentação e avaliar danos
E483	O transformador apresenta ponte de ligação primária ausente na configuração prevista.	A montagem do primário está sem a interligação entre terminais exigida pelo esquema.	Instalar a ponte correta
E484	O circuito do aquecedor apresenta condutor ligado ao contato auxiliar em vez do contato de potência do contator.	A conferência identificou alimentação da resistência terminada indevidamente no bloco auxiliar do contator.	Corrigir a ligação e avaliar danos
E485	O relé de supervisão apresenta contato de saída ligado ao terminal de alimentação por erro de fiação.	A conferência confirmou ligação incorreta entre o circuito de saída e a alimentação do relé de supervisão.	Corrigir a fiação
E486	A conexão do barramento apresenta terminal com área de contato inferior à especificada.	A montagem utiliza um terminal com superfície condutiva de união insuficiente para o projeto do barramento.	Instalar o terminal correto
E487	O contato de proteção do conector móvel está montado sem sua ligação condutiva interna.	O teste confirmou que o pino de aterramento do conector móvel não possui a conexão interna prevista.	Recompor ou substituir o conector
E488	O circuito de comando apresenta cabo preso no borne sobre a isolação, sem contato com o condutor.	A montagem do terminal fixou a capa isolante em vez da parte metálica do fio, deixando o comando aberto.	Refazer a terminação
E489	O conversor apresenta jumper de configuração elétrica instalado em posição diferente da especificada.	A conferência identificou ponte de configuração da placa do conversor no par de pinos incorreto.	Corrigir a configuração física
E490	O circuito de disparo apresenta resistor instalado com potência nominal inferior à especificada.	A conferência identificou resistor inadequado à dissipação prevista no circuito de disparo.	Instalar o componente correto
E491	O cabo de alimentação do módulo de potência apresenta terminal desconectado após perda da trava do conector.	A ruptura da retenção permitiu que a conexão de alimentação do módulo de potência se desprendesse.	Substituir o conector e restabelecer a ligação
E492	O circuito de descarga apresenta ligação do resistor conectada a dois pontos do mesmo potencial, contrariando o projeto.	A conferência confirmou que os dois terminais do resistor de descarga foram ligados ao mesmo potencial.	Corrigir as ligações
E493	O transmissor apresenta saída de corrente ligada a uma entrada configurada fisicamente para tensão.	A conferência identificou incompatibilidade entre a ligação de saída em corrente e a conexão de entrada em tensão do receptor.	Recompor a ligação conforme projeto
E494	O sensor apresenta alimentação interrompida em uma emenda oxidada.	O teste localizou circuito aberto na união oxidada do cabo de alimentação do sensor.	Refazer a emenda ou substituir o trecho
E495	O módulo de entrada apresenta conector encaixado parcialmente, deixando um canal sem contato.	A montagem incompleta do conector interrompe a ligação elétrica de um canal do módulo de entrada.	Corrigir o encaixe e verificar os contatos
E496	O circuito eletrônico do indicador apresenta resistor de entrada com valor fora da especificação por degradação.	O ensaio confirmou alteração indevida do valor resistivo na entrada eletrônica do indicador.	Reparar ou substituir o indicador


Lote 31 — mecânica
ID	Texto A	Texto B	Reparo principal
M481	O rolamento apresenta montagem com folga interna incompatível com a especificação do conjunto.	A conferência identificou rolamento de classe de folga diferente da prevista para a aplicação.	Instalar o rolamento correto
M482	A polia apresenta fixação montada com chaveta de comprimento insuficiente.	O comprimento da chaveta instalada na polia é inferior ao especificado para a união.	Instalar a chaveta correta e avaliar danos
M483	O eixo apresenta anel de retenção instalado em ranhura diferente da posição prevista.	A conferência confirmou travamento axial montado no canal incorreto do eixo.	Corrigir a montagem
M484	O acoplamento apresenta pino instalado sem a bucha de apoio especificada.	A montagem de um pino do acoplamento está incompleta por ausência da bucha prevista.	Instalar o componente e avaliar danos
M485	A bomba apresenta anel de desgaste com diâmetro incompatível com a folga de projeto.	A medição confirmou peça de desgaste instalada com dimensão inadequada ao ajuste da bomba.	Instalar o componente correto
M486	A válvula apresenta volante montado sem o elemento de retenção axial previsto.	A fixação do volante está incompleta porque falta sua trava axial especificada.	Instalar a trava e verificar a montagem
M487	A tubulação apresenta trecho montado com inclinação contrária à prevista para drenagem.	A conferência geométrica confirmou declive da linha em sentido oposto ao especificado para escoamento por gravidade.	Corrigir a montagem
M488	O suporte da tubulação apresenta guia instalada em posição que bloqueia o deslocamento axial previsto.	A montagem incorreta do apoio impede a movimentação longitudinal especificada para a linha.	Corrigir a disposição do suporte
M489	O cilindro hidráulico apresenta vedação com material diferente do aprovado para o fluido de serviço.	A conferência identificou anel vedante de composição incompatível com a especificação do circuito hidráulico.	Instalar a vedação correta
M490	A válvula pneumática apresenta conexão montada no escape onde o projeto prevê a alimentação.	A conferência identificou inversão das ligações físicas de alimentação e exaustão da válvula de ar.	Corrigir as conexões
M491	A mangueira de lubrificação apresenta terminal com passagem obstruída por resíduo de montagem.	O fluxo de lubrificante está bloqueado por material retido dentro do terminal da mangueira.	Limpar ou substituir e verificar a linha
M492	O reservatório hidráulico apresenta tampa de inspeção com parafusos de comprimento insuficiente.	A montagem da tampa utiliza fixadores sem o engajamento mínimo previsto.	Instalar os fixadores corretos
M493	O transportador apresenta raspador com pressão de contato acima da especificação por ajuste incorreto.	A regulagem excessiva força a lâmina do raspador contra a correia além do limite permitido.	Corrigir o ajuste e avaliar danos
M494	O carro apresenta conjunto de rodas montado com distância entre faces fora da tolerância.	A verificação dimensional confirmou espaçamento incorreto das rodas em relação à montagem especificada do carro.	Corrigir a montagem
M495	A proteção apresenta painel montado sem a distância de folga especificada em relação à parte móvel.	A montagem deixou a proteção próxima demais do componente em movimento, abaixo do afastamento previsto.	Corrigir o posicionamento
M496	O mecanismo apresenta pino com diâmetro inferior ao especificado e folga excessiva na articulação.	A conferência confirmou pino de dimensão incorreta na união articulada, provocando folga acima do limite.	Instalar o pino correto


Lote 32 — elétrica
ID	Texto A	Texto B	Reparo principal
E497	O motor apresenta condutor de proteção conectado a um terminal de fase por erro de montagem.	A conferência identificou o cabo de aterramento ligado indevidamente ao borne de potência do motor.	Corrigir a ligação e avaliar danos
E498	A bobina da válvula de processo apresenta terminal com corrosão e continuidade elétrica intermitente.	O ensaio localizou falha de contato no terminal oxidado da bobina da válvula de processo.	Recuperar ou substituir os componentes
E499	O transformador apresenta ligação secundária com emenda sem isolamento adequado e fuga para a estrutura.	O ensaio confirmou passagem de corrente da emenda do secundário à estrutura por falha de isolação.	Refazer a emenda conforme especificação
E500	O aquecedor apresenta espaçador isolante ausente entre o terminal e o suporte metálico.	A montagem do aquecedor está sem a peça prevista para separar eletricamente o terminal de seu suporte.	Instalar a isolação correta e avaliar danos
E501	O circuito da chave de emergência apresenta condutores de entrada e saída ligados ao mesmo terminal.	A conferência confirmou ligação incorreta que une entrada e saída em um único borne da chave de emergência.	Recompor conforme projeto
E502	O circuito de proteção apresenta fusível instalado com corrente nominal superior à especificada.	A conferência identificou elemento fusível com calibre acima do previsto para a proteção do circuito.	Instalar o fusível correto
E503	O terminal de alimentação apresenta contato inadequado por dois condutores instalados em borne não previsto para essa montagem.	A conexão utiliza dois fios em um terminal especificado para apenas um, comprometendo a fixação e o contato.	Recompor a terminação conforme especificação
E504	A conexão de proteção apresenta terminal montado com parafuso sem engajamento suficiente.	O fixador curto impede o aperto previsto da ligação de aterramento.	Instalar o fixador correto e conferir continuidade
E505	O circuito de potência apresenta polaridade de ligação do diodo de roda livre invertida.	A conferência confirmou montagem do diodo de circulação de corrente em sentido contrário ao esquema.	Corrigir a montagem e avaliar danos
E506	A placa de controle apresenta cabo de referência conectado com polaridade invertida.	Os dois condutores da referência de controle foram trocados nos terminais da placa.	Corrigir a ligação
E507	O resistor de frenagem apresenta potência nominal inferior à especificada para o conjunto.	A conferência identificou resistor instalado com capacidade de dissipação abaixo da prevista no projeto de frenagem.	Instalar o componente correto
E508	O circuito de alimentação do conversor apresenta fase ligada ao borne de proteção por erro de montagem.	A conferência identificou condutor de potência conectado indevidamente ao terminal de aterramento do conversor.	Corrigir a ligação e avaliar danos
E509	O sensor apresenta saída conectada ao canal de alimentação do receptor por erro de pinagem.	A pinagem incorreta liga o sinal do sensor a um terminal de alimentação do módulo receptor.	Corrigir a ligação e avaliar danos
E510	O módulo de comunicação apresenta alimentação interrompida no contato defeituoso da base de encaixe.	O teste localizou circuito aberto no contato que fornece energia ao módulo de comunicação através da base.	Substituir ou recuperar a base
E511	A chave seletora apresenta bloco de contato montado em posição incompatível com a função especificada.	A instalação incorreta do bloco altera a comutação elétrica prevista para a chave seletora.	Corrigir a montagem
E512	O indicador apresenta conector de entrada com terminal de sinal recuado e sem contato.	O sinal não chega ao indicador porque um pino recuou no conector de entrada.	Recuperar ou substituir o conector


Lote 32 — mecânica
ID	Texto A	Texto B	Reparo principal
M497	O eixo apresenta porca de fixação instalada sem a arruela de apoio especificada.	A montagem da retenção do eixo está sem a peça de apoio prevista sob a porca.	Corrigir a montagem e avaliar o ajuste
M498	A engrenagem apresenta montagem com interferência acima da especificação no eixo.	A medição confirmou ajuste excessivamente apertado entre o furo da engrenagem e o eixo.	Corrigir o ajuste ou substituir componentes
M499	A correia apresenta contato lateral com uma polia por espaçador de montagem incorreto.	A dimensão inadequada do espaçador deslocou a polia e provocou interferência na lateral da correia.	Corrigir a montagem e avaliar danos
M500	O acoplamento apresenta parafusos com engajamento de rosca inferior ao mínimo previsto.	A união do acoplamento foi montada com comprimento roscado insuficiente nos fixadores.	Instalar os componentes corretos
M501	A bomba apresenta parafuso de retenção do impulsor com travamento especificado ausente.	A montagem do fixador do impulsor está sem o recurso de bloqueio previsto no projeto.	Corrigir a montagem e verificar a fixação
M502	A válvula apresenta junta da tampa com material incompatível com a especificação do serviço.	A conferência identificou vedação de composição diferente da aprovada na união da tampa da válvula.	Instalar a junta correta
M503	A tubulação apresenta suporte montado sem o isolante mecânico previsto entre abraçadeira e tubo.	A montagem da fixação está sem a camada de separação especificada entre a abraçadeira e a tubulação.	Instalar o componente e avaliar o tubo
M504	O flange apresenta junta com diâmetro externo incompatível com a superfície prevista de assentamento.	A vedação instalada tem dimensão externa inadequada ao apoio especificado na união flangeada.	Instalar a junta correta
M505	O cilindro hidráulico apresenta haste montada com olhal de fixação de dimensão incompatível.	A conferência confirmou terminal de articulação incorreto instalado na haste hidráulica.	Instalar o componente especificado
M506	A válvula pneumática apresenta mola interna instalada em posição diferente da prevista na montagem.	A inspeção confirmou assentamento incorreto da mola no interior da válvula de ar.	Corrigir a montagem e avaliar componentes
M507	A mangueira hidráulica apresenta conexão de terminal incompatível com o padrão do ponto de ligação.	A conferência identificou terminal de mangueira inadequado à conexão especificada no equipamento.	Instalar os componentes corretos
M508	O sistema de lubrificação apresenta distribuidor montado sem a fixação prevista, permitindo deslocamento.	A ausência dos fixadores especificados deixa o distribuidor de lubrificante solto em seu suporte.	Completar a fixação e verificar as linhas
M509	O transportador apresenta rolete com rolamento montado fora da profundidade especificada no alojamento.	A verificação confirmou posicionamento axial incorreto do rolamento dentro do rolete.	Corrigir a montagem e avaliar componentes
M510	O carro apresenta conjunto de guia montado com espaçador de espessura excessiva.	A peça de ajuste instalada na guia do carro é mais espessa que a especificada no projeto.	Instalar o espaçador correto e conferir folgas
M511	A proteção apresenta dobradiça com fixador sem o travamento especificado e afrouxamento confirmado.	A ausência do recurso de bloqueio previsto permitiu que o parafuso da dobradiça da proteção perdesse aperto.	Corrigir a fixação
M512	O mecanismo apresenta pino de articulação com trava instalada sem assentamento completo.	O elemento de retenção do pino não está totalmente encaixado na posição prevista de travamento.	Corrigir a montagem e avaliar a trava

