Lote 18 — elétrica
ID	Texto A	Texto B	Reparo principal
E273	A bobina da mesa eletromagnética está eletricamente aberta.	O teste confirmou interrupção no enrolamento da mesa de fixação eletromagnética.	Recuperar ou substituir a bobina
E274	O cabo de alimentação do carro móvel apresenta condutor rompido na região de flexão.	A perda de continuidade foi localizada em um fio partido no trecho flexível do cabo do carro.	Substituir o cabo
E275	O enrolamento do transformador de soldagem apresenta fuga elétrica para o núcleo.	O ensaio confirmou perda de isolamento entre a bobina do transformador de soldagem e seu núcleo metálico.	Recuperar ou substituir o transformador
E276	O terminal da resistência do forno apresenta conexão frouxa com aquecimento localizado.	O aquecimento do terminal do forno foi associado ao aperto insuficiente da ligação da resistência.	Refazer a conexão e avaliar danos
E277	A chave de pedal apresenta contato elétrico que não fecha com o acionamento correto.	O mecanismo do pedal atua normalmente, mas seu contato permanece sem continuidade.	Substituir o contato ou conjunto
E278	A conexão de proteção da estrutura móvel está interrompida na trança flexível.	A ruptura da trança interrompeu o aterramento da parte móvel da estrutura.	Substituir a trança
E279	O terminal de alimentação do painel apresenta isolador quebrado e contato com a estrutura.	A ruptura do isolador permite que o terminal energizado encoste na estrutura metálica do painel.	Substituir o isolador ou conjunto
E280	O contato do relé de subtensão permanece aberto durante o ensaio de atuação previsto.	O teste funcional confirmou que a saída do relé de subtensão não fecha quando deveria atuar.	Reparar ou substituir o relé
E281	O retificador de soldagem apresenta conexão de saída carbonizada e resistência elevada.	O ensaio localizou resistência excessiva no terminal queimado de saída do retificador de soldagem.	Recuperar a conexão
E282	O circuito de acionamento do tiristor apresenta transformador de pulsos com falha de isolamento entre enrolamentos.	O ensaio confirmou perda de isolação entre primário e secundário do transformador de disparo do tiristor.	Substituir o transformador
E283	O capacitor do filtro de entrada do acionamento está eletricamente aberto.	O teste confirmou interrupção interna em um capacitor do filtro de alimentação do acionamento.	Substituir o capacitor
E284	O conector da placa de potência apresenta contato frouxo e alimentação intermitente.	A alimentação da placa de potência falha no contato sem pressão adequada de seu conector.	Substituir ou recuperar o conector
E285	O sensor de rotação apresenta cabo com curto entre sinal e blindagem aterrada.	O teste localizou curto elétrico entre o condutor de saída e a blindagem do cabo do sensor de rotação.	Substituir ou reparar o cabo
E286	O circuito de alimentação do transmissor apresenta borne com ponte elétrica ausente.	O transmissor não recebe alimentação porque falta a ponte prevista entre dois bornes.	Instalar a ponte especificada
E287	A bobina do relé de segurança está eletricamente aberta.	A medição confirmou interrupção no enrolamento do relé de segurança.	Substituir conforme especificação
E288	O circuito eletrônico de entrada do indicador de processo está danificado.	O ensaio com sinal de referência confirmou falha na aquisição do indicador de processo.	Reparar ou substituir o indicador


Lote 18 — mecânica
ID	Texto A	Texto B	Reparo principal
M273	O eixo apresenta canal do anel de retenção desgastado além da tolerância.	A medição confirmou desgaste excessivo na ranhura de travamento axial do eixo.	Recuperar ou substituir o eixo
M274	A transmissão apresenta correia instalada em canal de polia incompatível com seu perfil.	A conferência confirmou incompatibilidade entre o perfil da correia e o sulco da polia.	Instalar os componentes especificados
M275	O acoplamento apresenta bucha elastomérica de um pino rompida.	A inspeção confirmou ruptura da bucha de borracha que envolve um pino do acoplamento.	Substituir as buchas conforme especificação
M276	O redutor apresenta tampa de mancal sem os calços de ajuste especificados.	A montagem da tampa do mancal está sem o conjunto previsto de calços.	Corrigir a montagem e conferir ajustes
M277	A bomba apresenta anel de desgaste montado frouxo no corpo.	O anel de desgaste perdeu o ajuste de fixação no alojamento da bomba.	Recuperar o ajuste ou substituir componentes
M278	A válvula apresenta pino de articulação do obturador desgastado.	A folga do elemento de fechamento foi localizada no desgaste de seu pino de articulação.	Substituir o pino e verificar alojamentos
M279	A tubulação apresenta junta de flange cortada durante a montagem, com vazamento confirmado.	O vazamento na união foi localizado no corte causado à junta durante sua instalação.	Substituir a junta e corrigir a montagem
M280	O suporte da tubulação apresenta mola de sustentação fraturada.	A inspeção confirmou ruptura da mola do apoio da tubulação.	Substituir e reajustar o apoio
M281	O cilindro hidráulico apresenta haste com revestimento superficial descascado na região de vedação.	A inspeção identificou desprendimento do revestimento da haste onde atua a vedação hidráulica.	Recuperar ou substituir a haste
M282	O cilindro pneumático apresenta porca de fixação da haste ao mecanismo solta.	A ligação externa da haste pneumática perdeu aperto na porca de fixação ao mecanismo.	Restabelecer a fixação
M283	O regulador pneumático apresenta sede interna danificada, permitindo passagem de ar com o obturador fechado.	O ensaio confirmou vazamento interno pela sede comprometida do regulador de pressão de ar.	Recuperar ou substituir o conjunto
M284	A bomba de lubrificação apresenta engrenagem interna com dentes fraturados.	A inspeção confirmou ruptura de dentes no conjunto de engrenagens da bomba de lubrificante.	Substituir os componentes
M285	O transportador apresenta eixo de rolete deslocado por ausência da trava de montagem.	A falta do elemento de retenção permitiu o deslocamento do eixo do rolete no suporte.	Instalar a trava e avaliar danos
M286	O carro apresenta suporte do batente de impacto trincado.	A inspeção confirmou fissura na estrutura que fixa o batente de impacto do carro.	Recuperar ou substituir o suporte
M287	A proteção apresenta mola de sustentação com olhal de fixação fraturado.	O olhal de montagem da mola que sustenta a proteção está rompido.	Substituir a mola ou conjunto
M288	O mecanismo apresenta rolete seguidor com eixo frouxo no suporte.	A fixação do eixo do rolete seguidor perdeu aperto em seu suporte.	Restabelecer a fixação e avaliar danos


Lote 19 — elétrica
ID	Texto A	Texto B	Reparo principal
E289	A bobina do separador eletromagnético apresenta falha de isolamento para a estrutura.	O ensaio confirmou fuga elétrica entre o enrolamento do separador magnético e sua carcaça.	Recuperar ou substituir a bobina
E290	O terminal do enrolamento do motor apresenta isolação danificada por contato com uma aresta metálica.	O atrito contra uma borda metálica comprometeu o isolamento da ligação do enrolamento do motor.	Recuperar a isolação e corrigir o contato
E291	O transformador de comando apresenta ligação secundária configurada para tensão incorreta.	A conexão instalada no secundário do transformador fornece uma tensão diferente da prevista no projeto.	Corrigir a ligação
E292	O banco de resistências apresenta ligação interna interrompida por ruptura de um barramento.	A continuidade entre os resistores foi perdida em uma barra de interligação rompida.	Substituir a interligação
E293	O contato da chave de transferência apresenta resistência elevada na posição de serviço.	O ensaio confirmou resistência excessiva em um contato principal da chave de transferência fechada.	Recuperar ou substituir o conjunto
E294	O condutor de proteção apresenta terminal prensado com conexão eletricamente interrompida.	O teste localizou perda de continuidade na crimpagem do terminal do cabo de proteção.	Refazer a terminação
E295	O contato da chave de seleção de corrente está soldado e não abre na posição prevista.	O ensaio confirmou condução indevida por soldagem dos contatos da chave seletora de corrente.	Substituir a chave ou conjunto
E296	A base do relé apresenta ponte interna rompida entre terminal e contato de encaixe.	A continuidade da base do relé foi perdida na ligação interna ao contato que recebe o pino.	Substituir a base
E297	O módulo de potência apresenta terminal aparafusado com rosca danificada e conexão sem aperto adequado.	O terminal do módulo não permite fixação elétrica correta porque sua rosca está comprometida.	Substituir conforme especificação
E298	A placa do inversor apresenta resistor de alimentação do circuito de medição eletricamente aberto.	O ensaio confirmou interrupção no resistor que alimenta a eletrônica de medição do inversor.	Corrigir a causa e substituir o componente
E299	O diodo de proteção da entrada contínua está eletricamente aberto.	O teste identificou interrupção interna no diodo de proteção da alimentação em corrente contínua.	Substituir o diodo
E300	O circuito de disparo apresenta fibra óptica rompida, interrompendo o comando ao módulo de potência.	A ausência do comando de disparo foi localizada na ruptura da fibra óptica de ligação ao módulo.	Substituir a fibra e verificar a transmissão
E301	O cabo do sensor de temperatura apresenta blindagem em contato indevido com um condutor de sinal.	O ensaio confirmou curto entre a blindagem e um fio de sinal no cabo do sensor de temperatura.	Substituir ou reparar o cabo
E302	O contato de saída do controlador de pressão não fecha devido a defeito elétrico confirmado.	O teste confirmou circuito aberto no contato de saída do controlador de pressão quando comandado.	Substituir o relé ou controlador
E303	O módulo de alimentação dos sensores apresenta saída em curto por defeito eletrônico interno.	O diagnóstico localizou curto interno na fonte que alimenta os sensores.	Substituir ou reparar a fonte
E304	O sensor de fluxo apresenta circuito eletrônico de processamento danificado, com alimentação normal.	O ensaio confirmou defeito na eletrônica de processamento do sensor de fluxo, apesar da alimentação adequada.	Substituir o sensor


Lote 19 — mecânica
ID	Texto A	Texto B	Reparo principal
M289	O rolamento apresenta gaiola deformada e em contato indevido com os elementos rolantes.	A deformação da gaiola provoca interferência mecânica no movimento dos corpos rolantes.	Substituir o rolamento
M290	A polia apresenta parafuso de fixação radial frouxo, permitindo movimento no eixo.	A polia perdeu sua fixação porque o parafuso radial afrouxou.	Restabelecer a fixação e avaliar danos
M291	O acoplamento apresenta flange trincado.	A inspeção confirmou fissura estrutural no flange do acoplamento.	Substituir o componente
M292	O redutor apresenta engrenagem montada invertida em relação à orientação especificada.	A conferência de montagem confirmou orientação incorreta de uma engrenagem na caixa de transmissão.	Corrigir a montagem e conferir ajustes
M293	A bomba apresenta chave de fixação do impulsor cisalhada.	A transmissão de torque ao impulsor foi interrompida pelo cisalhamento de sua chaveta.	Substituir e verificar os alojamentos
M294	A válvula apresenta tampa com parafusos frouxos e perda do aperto de vedação.	A fixação da tampa da válvula perdeu pressão sobre a junta devido ao afrouxamento dos parafusos.	Recompor a união e verificar a vedação
M295	A tubulação apresenta solda de suporte rompida, deixando o trecho sem sustentação prevista.	A ruptura da união soldada do suporte retirou o apoio especificado da tubulação.	Recuperar o suporte e avaliar esforços
M296	O redutor apresenta visor de óleo com vedação ausente na montagem.	A conexão do visor à caixa de engrenagens foi montada sem o anel vedante previsto.	Instalar a vedação correta
M297	O cilindro hidráulico apresenta pistão com superfície de guia desgastada além da tolerância.	A medição confirmou desgaste excessivo na região de guiamento do pistão hidráulico.	Recuperar ou substituir o pistão
M298	A válvula pneumática apresenta carretel mecanicamente preso por contaminação sólida.	Os resíduos internos bloquearam o deslocamento do carretel da válvula pneumática.	Limpar ou substituir conforme diagnóstico
M299	O conjunto de lubrificação apresenta suporte da bomba com parafusos fraturados.	A bomba de lubrificante perdeu fixação por ruptura dos parafusos de seu suporte.	Recuperar a fixação e avaliar o conjunto
M300	A conexão hidráulica apresenta cone de vedação riscado e vazamento confirmado.	A perda de óleo foi localizada em riscos na superfície cônica de vedação da conexão.	Substituir os componentes comprometidos
M301	O transportador apresenta chapa de desgaste do chute perfurada por abrasão.	O desgaste abrasivo abriu uma perfuração no revestimento do chute do transportador.	Substituir o revestimento
M302	O carro apresenta guia lateral com folga excessiva por desgaste.	A medição confirmou desgaste além da tolerância na guia lateral do carro.	Substituir ou recuperar a guia
M303	A proteção apresenta cabo de sustentação com terminal desprendido.	A sustentação da proteção foi perdida porque o terminal se soltou do cabo.	Substituir ou recompor conforme especificação
M304	O mecanismo apresenta articulação montada sem a bucha especificada.	A montagem da articulação está sem a bucha prevista entre o pino e o alojamento.	Instalar a bucha e avaliar danos


Lote 20 — elétrica
ID	Texto A	Texto B	Reparo principal
E305	A bobina da válvula proporcional apresenta ligação interna eletricamente interrompida.	O teste confirmou circuito aberto na conexão interna do enrolamento da válvula proporcional.	Substituir a bobina ou conjunto
E306	O cabo de alimentação do freio apresenta condutor rompido junto ao conector.	A perda de continuidade da alimentação do freio foi localizada no fio partido próximo ao conector.	Substituir ou reparar o cabo
E307	O enrolamento do transformador de corrente apresenta interrupção elétrica interna.	O ensaio confirmou circuito aberto no enrolamento do transformador de corrente.	Substituir o transformador
E308	O cabo da resistência do forno está ligado a um terminal incompatível com o esquema.	A conferência identificou conexão incorreta do condutor de alimentação da resistência do forno.	Corrigir a ligação e avaliar danos
E309	O contato elétrico do intertravamento da chave seccionadora está soldado.	O contato de intertravamento não abre porque suas superfícies estão unidas por soldagem.	Substituir o bloco de contato
E310	O terminal do condutor de fase apresenta isolação rompida e fuga para a placa de montagem.	O ensaio confirmou passagem de corrente do terminal de fase para a chapa metálica devido à falha de isolamento.	Recompor ou substituir os componentes
E311	O circuito da bobina de fechamento apresenta fusível aberto, com causa já corrigida.	Após corrigir a causa da atuação, permanece interrompido o fusível que alimenta a bobina de fechamento.	Substituir o fusível
E312	A chave de seleção de alimentação apresenta ligação de saída trocada entre dois terminais.	A conferência confirmou inversão dos condutores de saída na chave seletora de alimentação.	Corrigir as ligações
E313	O circuito de pré-carga apresenta cabo de ligação do resistor eletricamente aberto.	A continuidade da pré-carga foi perdida em um fio rompido na ligação do resistor.	Substituir ou reparar o cabo
E314	O capacitor do barramento contínuo apresenta terminal interno desconectado e circuito aberto.	O ensaio confirmou interrupção interna no capacitor do barramento por perda da conexão ao terminal.	Substituir o capacitor
E315	O circuito eletrônico de proteção contra sobrecorrente do conversor está danificado.	O ensaio confirmou falha na eletrônica que detecta sobrecorrente no conversor.	Reparar ou substituir a placa
E316	O conector de saída do retificador apresenta isolamento carbonizado entre polos.	A carbonização do conector compromete a separação elétrica entre os terminais de saída do retificador.	Substituir o conector e corrigir a causa
E317	O sensor de posição apresenta conector com pino de sinal fraturado.	O sinal do sensor de posição está interrompido por ruptura de um terminal do conector.	Substituir o conector ou conjunto
E318	O circuito de alimentação do indicador apresenta polaridade invertida.	Os fios positivo e negativo estão trocados na alimentação do indicador.	Corrigir a ligação e avaliar danos
E319	O módulo de entrada digital apresenta curto interno entre dois canais.	O ensaio confirmou contato elétrico indevido entre circuitos de dois canais do módulo de entrada digital.	Reparar ou substituir o módulo
E320	O sinalizador luminoso apresenta LED eletricamente aberto.	O teste confirmou interrupção interna no LED do sinalizador luminoso.	Substituir o componente ou conjunto


Lote 20 — mecânica
ID	Texto A	Texto B	Reparo principal
M305	O eixo apresenta batimento radial acima da tolerância por montagem excêntrica no conjunto.	A verificação confirmou excentricidade de montagem que provoca batimento excessivo do eixo.	Corrigir a montagem e verificar o ajuste
M306	A roda dentada apresenta porca de retenção axial frouxa.	A fixação axial da roda dentada perdeu aperto na porca de retenção.	Restabelecer a fixação
M307	A correia apresenta contaminação por óleo com degradação confirmada de seu material.	A inspeção confirmou deterioração da correia causada pelo contato com óleo.	Substituir e eliminar a contaminação
M308	O acoplamento apresenta luva estriada com desgaste acima da tolerância.	A medição confirmou desgaste excessivo no estriado interno da luva do acoplamento.	Substituir os componentes desgastados
M309	A bomba apresenta tampa montada com aperto desigual, causando deformação da junta.	A distribuição incorreta do aperto da tampa deformou a vedação da bomba.	Corrigir a montagem e substituir a junta
M310	A válvula apresenta haste com superfície riscada na região das gaxetas.	A inspeção identificou sulcos na haste onde atuam os anéis de gaxeta da válvula.	Recuperar ou substituir a haste
M311	A tubulação apresenta apoio deslizante sem a placa de baixo atrito especificada.	O suporte foi montado sem o elemento previsto para permitir o deslizamento da tubulação.	Instalar a peça e verificar o apoio
M312	A união flangeada apresenta parafuso com rosca arrancada e perda de aperto.	A fixação do flange perdeu força porque os filetes do parafuso foram danificados.	Substituir e verificar a união
M313	O cilindro hidráulico apresenta vedação de pistão cortada durante a montagem.	A inspeção confirmou dano de instalação no anel vedante do pistão hidráulico.	Substituir e corrigir a montagem
M314	O regulador pneumático apresenta manípulo de travamento ausente.	O conjunto de ajuste do regulador está sem o componente que bloqueia sua posição de regulagem.	Instalar o componente especificado
M315	A válvula hidráulica apresenta assento do obturador com erosão além do limite.	A inspeção confirmou perda excessiva de material na sede de fechamento da válvula hidráulica.	Recuperar ou substituir o conjunto
M316	O reservatório de graxa apresenta tampa deformada e sem assentamento adequado.	O empenamento da tampa impede o fechamento especificado do reservatório de lubrificante.	Recuperar ou substituir a tampa
M317	O transportador apresenta suporte lateral do tambor deformado.	A inspeção confirmou empenamento na estrutura lateral que sustenta o tambor do transportador.	Recuperar ou substituir o suporte
M318	O carro apresenta rolamento de guia com anel externo fraturado.	A inspeção confirmou ruptura da pista externa do rolamento que guia o carro.	Substituir o rolamento
M319	A proteção apresenta trilho de deslizamento com resíduos que bloqueiam o movimento.	O acúmulo de material na guia impede deslocar normalmente a proteção.	Limpar e verificar a guia
M320	O mecanismo apresenta pino de ligação montado com comprimento insuficiente para sua retenção.	O pino instalado é curto demais para permitir o travamento especificado da articulação.	Instalar o pino correto


Lote 21 — elétrica
ID	Texto A	Texto B	Reparo principal
E321	O motor apresenta terminal de ligação trincado e continuidade elétrica intermitente.	A fissura no terminal do motor provoca interrupções na conexão elétrica.	Substituir o terminal e avaliar a ligação
E322	A bobina do alimentador vibratório apresenta fuga elétrica para a estrutura.	O ensaio confirmou perda de isolamento entre o enrolamento do alimentador vibratório e sua carcaça.	Recuperar ou substituir a bobina
E323	O transformador apresenta ligação de blindagem interna conectada a um terminal diferente do previsto no projeto.	A conferência identificou a blindagem do transformador terminada em ponto incorreto do circuito.	Corrigir a conexão
E324	O circuito de aquecimento apresenta resistência ligada sem a interligação elétrica prevista entre os elementos.	A montagem do aquecedor está sem a ponte condutiva especificada entre duas resistências.	Instalar a interligação correta
E325	O contato de saída do relé de supervisão de frequência apresenta resistência elevada quando fechado.	O ensaio confirmou resistência excessiva na saída acionada do relé de frequência.	Reparar ou substituir o relé
E326	O circuito do medidor apresenta cabo de tensão com condutor interrompido.	A ausência do sinal de tensão no medidor foi localizada em um fio rompido de seu cabo.	Reparar ou substituir o cabo
E327	O terminal de saída da chave seccionadora está carbonizado e provoca contato intermitente.	A continuidade da saída da seccionadora falha no terminal queimado.	Substituir os componentes danificados
E328	A ligação de proteção da caixa de passagem está desconectada internamente.	A caixa metálica perdeu sua conexão de aterramento porque o condutor interno se soltou.	Restabelecer a ligação
E329	O circuito de disparo do conversor apresenta optoacoplador eletronicamente danificado.	O ensaio localizou falha de transmissão do comando no optoacoplador do circuito de disparo.	Substituir o componente ou placa
E330	O resistor de frenagem apresenta terminal com conexão frouxa e centelhamento.	O arco elétrico foi localizado na ligação mal apertada do terminal do resistor de frenagem.	Refazer a conexão e avaliar danos
E331	O cabo de referência analógica do acionamento apresenta curto entre sinal e retorno.	O ensaio confirmou curto-circuito entre os condutores da referência analógica de comando do acionamento.	Reparar ou substituir o cabo
E332	A fonte auxiliar do conversor apresenta capacitor de filtragem em curto.	O ensaio identificou curto interno no capacitor de filtro da alimentação auxiliar do conversor.	Substituir o componente ou conjunto
E333	O sensor de velocidade apresenta circuito eletrônico de alimentação interna danificado.	O diagnóstico confirmou falha na fonte interna do sensor de velocidade.	Substituir ou reparar o sensor
E334	O módulo de saída apresenta terminal de alimentação com solda rompida.	A alimentação do módulo de saída está interrompida na solda de seu terminal.	Recuperar ou substituir o módulo
E335	O contato da chave de habilitação não comuta apesar do acionamento mecânico correto.	O mecanismo da chave de habilitação atua normalmente, mas seu contato elétrico não muda de estado.	Substituir o contato ou conjunto
E336	O cabo de comunicação apresenta par diferencial ligado com polaridade trocada nos terminais.	A conferência identificou inversão dos dois fios do sinal diferencial na conexão da rede.	Corrigir a ligação conforme especificação


Lote 21 — mecânica
ID	Texto A	Texto B	Reparo principal
M321	O mancal apresenta base deformada e perda do assentamento no suporte.	O empenamento da base do mancal impede seu apoio conforme especificação.	Recuperar ou substituir o mancal
M322	A engrenagem apresenta dente com deformação plástica acima da tolerância.	A inspeção confirmou alteração permanente do perfil de um dente da engrenagem além do limite permitido.	Substituir e investigar a causa
M323	A corrente apresenta elo montado invertido em relação à orientação especificada.	A conferência de montagem identificou orientação incorreta de um elo da corrente.	Corrigir a montagem e avaliar danos
M324	O acoplamento apresenta parafuso de comprimento excessivo em contato com parte adjacente.	O fixador instalado ultrapassa a dimensão prevista e interfere mecanicamente em um componente próximo.	Instalar o fixador especificado
M325	A bomba apresenta retentor instalado com o lábio voltado para o lado incorreto.	A conferência confirmou orientação invertida do retentor do eixo da bomba.	Substituir e corrigir a montagem
M326	A válvula apresenta suporte do atuador mecânico trincado.	A inspeção confirmou fissura na estrutura que sustenta o acionamento mecânico da válvula.	Recuperar ou substituir o suporte
M327	A tubulação apresenta junta de expansão instalada além de seu comprimento de montagem permitido.	A medição confirmou alongamento excessivo da junta de expansão na condição instalada.	Corrigir a montagem e avaliar o conjunto
M328	A flange apresenta prisioneiro com porca solta e perda de compressão da junta.	A união perdeu aperto de vedação porque a porca de um prisioneiro afrouxou.	Recompor a união e avaliar a junta
M329	O cilindro pneumático apresenta tampa com parafuso de fixação fraturado.	A inspeção confirmou ruptura de um fixador da tampa do cilindro pneumático.	Substituir e verificar o conjunto
M330	A mangueira hidráulica apresenta raio de curvatura menor que o mínimo especificado.	A montagem força a mangueira de óleo a uma dobra mais fechada que o limite permitido.	Corrigir a instalação e avaliar a mangueira
M331	A válvula de retenção hidráulica apresenta mola montada fora do alojamento.	A inspeção confirmou posicionamento incorreto da mola interna da válvula hidráulica de retenção.	Corrigir a montagem e avaliar componentes
M332	A conexão de lubrificação apresenta rosca cruzada, impedindo montagem e vedação corretas.	O terminal da linha de lubrificante foi rosqueado incorretamente e comprometeu a união.	Substituir ou recuperar os componentes
M333	O transportador apresenta rolete com vedação lateral ausente.	A montagem do rolete está sem o elemento de vedação previsto em sua extremidade.	Instalar a vedação e inspecionar o conjunto
M334	O carro apresenta mecanismo de travamento com pino fraturado.	O bloqueio mecânico do carro falhou por ruptura de seu pino de travamento.	Substituir e verificar o mecanismo
M335	A proteção apresenta fechadura desalinhada em relação ao batente.	O desalinhamento entre a fechadura e seu ponto de engate impede o fechamento correto da proteção.	Corrigir o alinhamento
M336	O mecanismo apresenta mola de torção com uma extremidade fraturada.	A inspeção confirmou ruptura de uma ponta da mola de torção do mecanismo.	Substituir a mola

